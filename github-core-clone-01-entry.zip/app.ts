// The HTTP router: health probe, git smart HTTP, REST v3, GraphQL v4 and MCP, all on one
// server bound to an ephemeral port by main.ts. Every reply carries X-GitHub-Request-Id; every
// API reply is JSON, never HTML; a missing or wrong bearer token is a 401.

import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { VIEWER } from './scenario.ts';
import { Store } from './store.ts';
import { handleRest, jsonError } from './rest.ts';
import { handleGraphQL } from './graphql.ts';
import { handleMcp } from './mcp.ts';
import {
  advertisementV0,
  advertisementV2,
  applyPush,
  handleFetch,
  handleLsRefs,
  newRequestId,
  parseV2Request,
  pushReportResponse,
} from './gitproto.ts';

const store = new Store();

function send(res: ServerResponse, status: number, contentType: string, body: Buffer, headers: Record<string, string> = {}): void {
  res.writeHead(status, {
    'content-type': contentType,
    'content-length': body.length,
    'x-github-request-id': newRequestId(),
    ...headers,
  });
  res.end(body);
}

function unauthorizedJson(res: ServerResponse, value: unknown = { message: 'Requires authentication' }): void {
  // The WWW-Authenticate header tells a real git client it may retry with Basic credentials
  // (the token as username or password); without it git gives up after the first 401.
  sendJson(res, 401, value, { 'www-authenticate': 'Basic realm="forge", Bearer' });
}

function sendJson(res: ServerResponse, status: number, value: unknown, headers: Record<string, string> = {}): void {
  const text = `${JSON.stringify(value)}\n`;
  send(res, status, 'application/json; charset=utf-8', Buffer.from(text, 'utf8'), headers);
}

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise<Buffer>((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

/** The bearer token this process expects, from the trial environment. */
function expectedToken(): string {
  return process.env.MAKEFUN_SHOP_TOKEN ?? '';
}

function authorized(req: IncomingMessage): boolean {
  const header = req.headers.authorization ?? '';
  const expected = expectedToken();
  if (header.startsWith('Bearer ')) {
    if (expected === '') return true;
    return header === `Bearer ${expected}`;
  }
  // Real git clients send Basic auth (token as the username or the password); accept either
  // form of the same credential, so a plain `git clone` works against the forge too.
  if (header.startsWith('Basic ') && expected !== '') {
    try {
      const decoded = Buffer.from(header.slice(6), 'base64').toString('utf8');
      const colon = decoded.indexOf(':');
      const user = colon < 0 ? decoded : decoded.slice(0, colon);
      const pass = colon < 0 ? '' : decoded.slice(colon + 1);
      return user === expected || pass === expected;
    } catch {
      return false;
    }
  }
  return false;
}

function pathOf(req: IncomingMessage): string {
  try {
    return new URL(req.url ?? '/', 'http://entry').pathname;
  } catch {
    return '/';
  }
}

function queryOf(req: IncomingMessage): URLSearchParams {
  try {
    return new URL(req.url ?? '/', 'http://entry').searchParams;
  } catch {
    return new URLSearchParams();
  }
}

/** Build the router. It binds nothing until the caller listens; the entry listens on an ephemeral port. */
export function createApp(): Server {
  return createServer((req: IncomingMessage, res: ServerResponse) => {
    void handleRequest(req, res).catch((err: unknown) => {
      try {
        sendJson(res, 500, { message: err instanceof Error ? err.message : 'Internal Server Error' });
      } catch {
        // The response is already gone; nothing left to do.
      }
    });
  });
}

async function handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const path = pathOf(req);
  const method = req.method ?? 'GET';

  // The env's boot check calls this twice: 200 {"ok":true}. No token needed.
  if (method === 'GET' && path === '/healthz') {
    sendJson(res, 200, { ok: true });
    return;
  }

  // Git smart HTTP: /{owner}/{repo}.git/info/refs, /git-upload-pack, /git-receive-pack.
  const gitMatch = /^\/([^/]+)\/([^/]+)\.git\/(info\/refs|git-upload-pack|git-receive-pack)$/.exec(path);
  if (gitMatch !== null) {
    await handleGit(req, res, gitMatch[1] as string, gitMatch[2] as string, gitMatch[3] as string);
    return;
  }

  // GraphQL v4.
  if (path === '/api/graphql') {
    if (method !== 'POST') {
      sendJson(res, 404, { message: 'Not Found' });
      return;
    }
    if (!authorized(req)) {
      unauthorizedJson(res, { message: 'Requires authentication' });
      return;
    }
    const body = await readBody(req);
    let parsed: unknown;
    try {
      parsed = JSON.parse(body.toString('utf8')) as unknown;
    } catch {
      sendJson(res, 400, { message: 'Malformed JSON body' });
      return;
    }
    const answer = handleGraphQL(parsed, store);
    sendJson(res, answer.status, answer.value);
    return;
  }

  // Model Context Protocol.
  if (path === '/mcp') {
    if (method !== 'POST') {
      sendJson(res, 404, { message: 'Not Found' });
      return;
    }
    if (!authorized(req)) {
      unauthorizedJson(res, { jsonrpc: '2.0', id: null, error: { code: -32000, message: 'Requires authentication' } });
      return;
    }
    const body = await readBody(req);
    const answer = handleMcp(body, store);
    send(res, answer.status, answer.contentType, answer.body, answer.headers ?? {});
    return;
  }

  // REST v3.
  if (path === '/api/v3' || path.startsWith('/api/v3/')) {
    if (!authorized(req)) {
      unauthorizedJson(res, { message: 'Requires authentication' });
      return;
    }
    const body = await readBody(req);
    let parsed: unknown = undefined;
    if (body.length > 0 && (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE')) {
      try {
        parsed = JSON.parse(body.toString('utf8')) as unknown;
      } catch {
        sendJson(res, 400, { message: 'Malformed JSON body' });
        return;
      }
    }
    const baseUrl = `http://${req.headers.host ?? 'localhost'}`;
    const answer = handleRest(method, path, queryOf(req), parsed, store, baseUrl);
    send(res, answer.status, answer.contentType, answer.body, answer.headers ?? {});
    return;
  }

  sendJson(res, 404, { message: 'Not Found' });
}

async function handleGit(
  req: IncomingMessage,
  res: ServerResponse,
  owner: string,
  repoName: string,
  service: string,
): Promise<void> {
  const method = req.method ?? 'GET';
  if (!authorized(req)) {
    unauthorizedJson(res, { message: 'Requires authentication' });
    return;
  }
  if (owner !== VIEWER.login) {
    sendJson(res, 404, { message: 'Not Found' });
    return;
  }
  const repo = store.getRepo(owner, repoName);
  if (repo === null || repo === undefined) {
    sendJson(res, 404, { message: 'Not Found' });
    return;
  }

  if (service === 'info/refs' && method === 'GET') {
    const query = queryOf(req);
    const serviceName = query.get('service');
    if (serviceName === 'git-upload-pack') {
      const protocol = req.headers['git-protocol'];
      if (protocol === 'version=2') {
        send(res, 200, 'application/x-git-upload-pack-advertisement', advertisementV2());
      } else {
        send(res, 200, 'application/x-git-upload-pack-advertisement', advertisementV0(repo, 'git-upload-pack'));
      }
      return;
    }
    if (serviceName === 'git-receive-pack') {
      send(res, 200, 'application/x-git-receive-pack-advertisement', advertisementV0(repo, 'git-receive-pack'));
      return;
    }
    sendJson(res, 404, { message: 'Not Found' });
    return;
  }

  if (service === 'git-upload-pack' && method === 'POST') {
    const body = await readBody(req);
    const protocol = req.headers['git-protocol'];
    if (protocol !== 'version=2') {
      sendJson(res, 400, { message: 'This server requires Git-Protocol: version=2 for upload-pack' });
      return;
    }
    const request = parseV2Request(body);
    if (request.command === 'ls-refs') {
      send(res, 200, 'application/x-git-upload-pack-result', handleLsRefs(repo, request.lsRefs));
      return;
    }
    if (request.command === 'fetch') {
      send(res, 200, 'application/x-git-upload-pack-result', handleFetch(repo, request.fetch));
      return;
    }
    sendJson(res, 400, { message: `Unknown upload-pack command: ${request.command}` });
    return;
  }

  if (service === 'git-receive-pack' && method === 'POST') {
    const body = await readBody(req);
    const result = applyPush(repo, body);
    send(res, 200, 'application/x-git-receive-pack-result', pushReportResponse(result));
    return;
  }

  sendJson(res, 404, { message: 'Not Found' });
}

export { jsonError };
