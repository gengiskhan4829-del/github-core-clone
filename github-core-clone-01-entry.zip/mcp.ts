// The Model Context Protocol endpoint: JSON-RPC 2.0 over Streamable HTTP, revision 2026-07-28
// (with the pre-discover handshake as a fallback). The tools act on the same store as REST, so
// a repository or issue created here reads back over /api/v3 as the same object.

import { VIEWER } from './scenario.ts';
import { issueGlobalId, pullGlobalId, repoGlobalId, type Issue, type PullRequest, type Repo, type Store } from './store.ts';

export interface McpResult {
  status: number;
  contentType: string;
  headers?: Record<string, string>;
  body: Buffer;
}

function jsonBody(status: number, value: unknown, headers: Record<string, string> = {}): McpResult {
  const text = `${JSON.stringify(value)}\n`;
  return { status, contentType: 'application/json', headers, body: Buffer.from(text, 'utf8') };
}

const SERVER_INFO = { name: 'github-core-clone', version: '1.0.0' };
const PREFERRED_REVISION = '2026-07-28';
const SUPPORTED_REVISIONS = ['2026-07-28', '2025-11-25', '2025-06-18', '2025-03-26', '2024-11-05'];
const SESSION_ID = 'mcp-session-1';

interface ToolDef {
  name: string;
  description: string;
  inputSchema: { type: 'object'; properties: Record<string, { type: string; description: string }>; required: string[] };
}

const TOOLS: ToolDef[] = [
  {
    name: 'create_repo',
    description: 'Create a new repository for the authenticated user.',
    inputSchema: {
      type: 'object',
      properties: {
        name: { type: 'string', description: 'The name of the repository to create.' },
        description: { type: 'string', description: 'A short description of the repository.' },
        private: { type: 'boolean', description: 'Whether the repository is private.' },
      },
      required: ['name'],
    },
  },
  {
    name: 'get_repo',
    description: 'Get a repository by owner and name.',
    inputSchema: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'The owner of the repository.' },
        repo: { type: 'string', description: 'The name of the repository.' },
        full_name: { type: 'string', description: 'The full name of the repository, owner/repo.' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'create_issue',
    description: 'Create an issue in a repository.',
    inputSchema: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'The owner of the repository.' },
        repo: { type: 'string', description: 'The name of the repository.' },
        title: { type: 'string', description: 'The title of the issue.' },
        body: { type: 'string', description: 'The body of the issue.' },
        full_name: { type: 'string', description: 'The full name of the repository, owner/repo.' },
      },
      required: ['owner', 'repo', 'title'],
    },
  },
  {
    name: 'list_issues',
    description: 'List issues in a repository, optionally filtered by state.',
    inputSchema: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'The owner of the repository.' },
        repo: { type: 'string', description: 'The name of the repository.' },
        state: { type: 'string', description: 'The state to filter by: open, closed or all.' },
        full_name: { type: 'string', description: 'The full name of the repository, owner/repo.' },
      },
      required: ['owner', 'repo'],
    },
  },
  {
    name: 'create_pull_request',
    description: 'Open a pull request from a head branch into a base branch.',
    inputSchema: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'The owner of the repository.' },
        repo: { type: 'string', description: 'The name of the repository.' },
        title: { type: 'string', description: 'The title of the pull request.' },
        body: { type: 'string', description: 'The body of the pull request.' },
        head: { type: 'string', description: 'The head branch name.' },
        base: { type: 'string', description: 'The base branch name.' },
        full_name: { type: 'string', description: 'The full name of the repository, owner/repo.' },
      },
      required: ['owner', 'repo', 'title', 'head', 'base'],
    },
  },
  {
    name: 'merge_pull_request',
    description: 'Merge a pull request with a squash commit.',
    inputSchema: {
      type: 'object',
      properties: {
        owner: { type: 'string', description: 'The owner of the repository.' },
        repo: { type: 'string', description: 'The name of the repository.' },
        pull_number: { type: 'integer', description: 'The number of the pull request to merge.' },
        full_name: { type: 'string', description: 'The full name of the repository, owner/repo.' },
      },
      required: ['owner', 'repo', 'pull_number'],
    },
  },
];

function repoJson(repo: Repo): Record<string, unknown> {
  return {
    id: repo.id,
    node_id: repoGlobalId(repo),
    name: repo.name,
    full_name: `${repo.owner}/${repo.name}`,
    owner: { login: repo.owner, id: VIEWER.id, type: 'User' },
    private: repo.private,
    description: repo.description,
    default_branch: repo.defaultBranch,
    created_at: repo.createdAt,
  };
}

function issueJson(repo: Repo, issue: Issue): Record<string, unknown> {
  return {
    id: issue.id,
    node_id: issueGlobalId(repo, issue),
    number: issue.number,
    title: issue.title,
    body: issue.body,
    state: issue.state,
    labels: issue.labels.map((name) => ({ name })),
    created_at: issue.createdAt,
    updated_at: issue.updatedAt,
  };
}

function pullJson(repo: Repo, pull: PullRequest): Record<string, unknown> {
  return {
    id: pull.id,
    node_id: pullGlobalId(repo, pull),
    number: pull.number,
    title: pull.title,
    body: pull.body,
    state: pull.state,
    head: { ref: pull.headRef, sha: pull.headSha },
    base: { ref: pull.baseRef, sha: pull.baseSha },
    merged: pull.merged,
    merged_at: pull.mergedAt,
    merge_commit_sha: pull.mergeCommitSha,
    created_at: pull.createdAt,
    updated_at: pull.updatedAt,
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Resolve owner/repo from the arguments, accepting full_name as a fallback. */
function resolveRepo(store: Store, args: Record<string, unknown>): Repo | null {
  let owner = typeof args.owner === 'string' ? args.owner : '';
  let name = typeof args.repo === 'string' ? args.repo : '';
  if ((owner === '' || name === '') && typeof args.full_name === 'string') {
    const [o, n] = (args.full_name as string).split('/');
    if (o !== undefined && n !== undefined) {
      owner = o;
      name = n;
    }
  }
  if (owner !== VIEWER.login) return null;
  return store.getRepo(owner, name) ?? null;
}

function toolResult(data: unknown): Record<string, unknown> {
  return { content: [{ type: 'text', text: JSON.stringify(data) }], structuredContent: data };
}

function toolError(message: string): Record<string, unknown> {
  return { content: [{ type: 'text', text: message }], isError: true };
}

function callTool(store: Store, name: string, args: Record<string, unknown>): Record<string, unknown> {
  const missing = (required: string[]): string | null => {
    const absent = required.filter((key) => args[key] === undefined || args[key] === null || args[key] === '');
    return absent.length > 0 ? `Missing required argument(s): ${absent.join(', ')}` : null;
  };

  switch (name) {
    case 'create_repo': {
      const problem = missing(['name']);
      if (problem !== null) return toolError(problem);
      const repoName = args.name as string;
      if (store.getRepo(VIEWER.login, repoName) !== undefined) return toolError(`Repository ${repoName} already exists`);
      const repo = store.createRepo(VIEWER.login, repoName, {
        description: typeof args.description === 'string' ? args.description : '',
        private: args.private === true,
      });
      if (repo === null) return toolError('Repository creation failed');
      return toolResult(repoJson(repo));
    }
    case 'get_repo': {
      const repo = resolveRepo(store, args);
      if (repo === null) return toolError('Repository not found');
      return toolResult(repoJson(repo));
    }
    case 'create_issue': {
      const problem = missing(['title']);
      if (problem !== null) return toolError(problem);
      const repo = resolveRepo(store, args);
      if (repo === null) return toolError('Repository not found');
      repo.issueSeq += 1;
      const stamp = store.stamp();
      const issue: Issue = {
        id: store.nextId(),
        number: repo.issueSeq,
        title: args.title as string,
        body: typeof args.body === 'string' ? args.body : '',
        state: 'open',
        labels: [],
        comments: [],
        createdAt: stamp,
        updatedAt: stamp,
        seq: repo.issueSeq,
      };
      repo.issues.set(issue.number, issue);
      return toolResult(issueJson(repo, issue));
    }
    case 'list_issues': {
      const repo = resolveRepo(store, args);
      if (repo === null) return toolError('Repository not found');
      const state = typeof args.state === 'string' ? args.state : 'open';
      let issues = [...repo.issues.values()];
      if (state !== 'all') issues = issues.filter((issue) => issue.state === state);
      issues.sort((a, b) => b.seq - a.seq);
      return toolResult({ issues: issues.map((issue) => issueJson(repo, issue)) });
    }
    case 'create_pull_request': {
      const problem = missing(['title', 'head', 'base']);
      if (problem !== null) return toolError(problem);
      const repo = resolveRepo(store, args);
      if (repo === null) return toolError('Repository not found');
      const headRef = args.head as string;
      const baseRef = args.base as string;
      const headSha = repo.refs.get(`refs/heads/${headRef}`);
      const baseSha = repo.refs.get(`refs/heads/${baseRef}`);
      if (headSha === undefined || baseSha === undefined) return toolError('head or base branch does not exist');
      repo.pullSeq += 1;
      const stamp = store.stamp();
      const pull: PullRequest = {
        id: store.nextId(),
        number: repo.pullSeq,
        title: args.title as string,
        body: typeof args.body === 'string' ? args.body : '',
        state: 'open',
        headRef,
        headSha,
        baseRef,
        baseSha,
        merged: false,
        mergedAt: null,
        mergeCommitSha: null,
        createdAt: stamp,
        updatedAt: stamp,
        seq: repo.pullSeq,
      };
      repo.pulls.set(pull.number, pull);
      return toolResult(pullJson(repo, pull));
    }
    case 'merge_pull_request': {
      const problem = missing(['pull_number']);
      if (problem !== null) return toolError(problem);
      const repo = resolveRepo(store, args);
      if (repo === null) return toolError('Repository not found');
      const number = Number(args.pull_number);
      const pull = repo.pulls.get(number);
      if (pull === undefined) return toolError('Pull request not found');
      if (pull.state !== 'open') return toolError('Pull request is already closed');
      const merged = store.mergePull(repo, pull);
      if (merged === null) return toolError('Merge conflict');
      pull.merged = true;
      pull.state = 'closed';
      pull.mergedAt = store.stamp();
      pull.mergeCommitSha = merged.sha;
      pull.updatedAt = store.stamp();
      return toolResult({ number: pull.number, merged: true, sha: merged.sha, state: 'closed' });
    }
    default:
      return { error: { code: -32602, message: `Unknown tool: ${name}` } };
  }
}

/**
 * Handle one POST /mcp request. `rawBody` is the request bytes: a body that is not JSON answers
 * HTTP 400 with JSON-RPC -32700. Returns the HTTP answer.
 */
export function handleMcp(rawBody: Buffer, store: Store): McpResult {
  let request: unknown;
  try {
    request = JSON.parse(rawBody.toString('utf8')) as unknown;
  } catch {
    return jsonBody(400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } });
  }
  if (!isRecord(request) || typeof request.method !== 'string') {
    return jsonBody(400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } });
  }
  const id = request.id === undefined ? null : request.id;
  const method = request.method as string;
  const params = isRecord(request.params) ? request.params : {};
  const sessionHeaders = { 'mcp-session-id': SESSION_ID };

  // Notifications carry no id and get no JSON-RPC answer.
  if (id === null && method.startsWith('notifications/')) {
    return { status: 202, contentType: 'application/json', headers: sessionHeaders, body: Buffer.alloc(0) };
  }

  const result = (value: unknown): McpResult => jsonBody(200, { jsonrpc: '2.0', id, result: value }, sessionHeaders);
  const error = (code: number, message: string, status = 200): McpResult =>
    jsonBody(status, { jsonrpc: '2.0', id, error: { code, message } }, sessionHeaders);

  if (method === 'server/discover') {
    return result({
      protocolVersion: PREFERRED_REVISION,
      supportedVersions: [...SUPPORTED_REVISIONS],
      capabilities: { tools: {} },
      serverInfo: { ...SERVER_INFO },
    });
  }

  if (method === 'initialize') {
    const offered = typeof params.protocolVersion === 'string' ? params.protocolVersion : PREFERRED_REVISION;
    const negotiated = SUPPORTED_REVISIONS.includes(offered) ? offered : '2025-11-25';
    return result({
      protocolVersion: negotiated,
      capabilities: { tools: {} },
      serverInfo: { ...SERVER_INFO },
    });
  }

  if (method === 'tools/list') {
    return result({ tools: TOOLS });
  }

  if (method === 'tools/call') {
    const toolName = typeof params.name === 'string' ? params.name : '';
    const args = isRecord(params.arguments) ? (params.arguments as Record<string, unknown>) : {};
    const outcome = callTool(store, toolName, args);
    if ('error' in outcome) {
      const err = outcome.error as { code: number; message: string };
      return error(err.code, err.message);
    }
    return result(outcome);
  }

  return error(-32601, `Method not found: ${method}`);
}
