# github-core-clone

[![make.fun · github-core-clone-01](https://make.fun/badge/github-core-clone-01.svg)](https://make.fun/bounty/github-core-clone-01?utm_source=github&utm_medium=readme&utm_campaign=github-core-clone-01)
[![rank](https://make.fun/badge/github-core-clone-01/gengiskhan4829-del/github-core-clone/rank.svg)](https://make.fun/bounty/github-core-clone-01/leaderboard?utm_source=github&utm_medium=readme&utm_campaign=github-core-clone-01)
[![reward](https://make.fun/badge/github-core-clone-01/gengiskhan4829-del/github-core-clone/reward.svg)](https://make.fun/bounty/github-core-clone-01?utm_source=github&utm_medium=readme&utm_campaign=github-core-clone-01)

A standalone, GitHub-compatible git forge in a single process. No UI, no `git`
binary, no outside service, no dependencies — just the Node.js standard
library. It speaks the protocols a real client needs and nothing it doesn't:

- **git smart HTTP** — protocol v2 `upload-pack` (`ls-refs`, `fetch` with
  shallow/deepen, haves negotiation with ACK/NAK + `ready`) and v0
  `receive-pack` (create/update/delete refs, report-status over sideband).
- **REST v3** under `/api/v3` — repositories, branches, commits, contents,
  labels, issues, issue comments, and pull requests with squash merge.
- **GraphQL** at `/api/graphql` — viewer, repository, node, issues and pull
  request connections with cursor pagination, the five mutations, batched
  requests, and schema introspection.
- **MCP** at `/mcp` — JSON-RPC 2.0 with `server/discover`, `initialize`, and
  six tools (`create_repo`, `get_repo`, `create_issue`, `list_issues`,
  `create_pull_request`, `merge_pull_request`).

## Running it

```sh
node --experimental-strip-types main.ts
```

`main.ts` is the harness lifecycle: bind an ephemeral port, register it with
the environment (`MAKEFUN_ENV_URL`), then poll `/done` until the trial ends
and exit 0. The server itself is `createApp()` in `app.ts`; the bearer token
it expects comes from `MAKEFUN_SHOP_TOKEN`.

## Layout

| File | What it does |
| --- | --- |
| `main.ts` | Lifecycle: bind, register, wait for done, exit. |
| `app.ts` | HTTP router and auth (Bearer, plus Basic for plain `git` clients). Every response carries `X-GitHub-Request-Id`. |
| `store.ts` | The object model: SHA-1 objects, trees, commits, tags, reachability, merges, and the in-memory store with a deterministic clock. |
| `gitproto.ts` | The wire: pkt-lines, pack reading/writing (OFS/REF deltas), v2 fetch planning, and push application. |
| `rest.ts` | The REST v3 handlers. |
| `graphql.ts` | A small GraphQL tokenizer, parser, and executor for the supported documents. |
| `mcp.ts` | The MCP tools, backed by the same store as REST and GraphQL. |
| `scenario.ts` | Derives the trial's viewer and stranger identities from the scenario seed, the same way the harness does. |

## Design notes

- **One store, four surfaces.** REST, GraphQL, MCP, and git all read and write
  the same in-memory repositories, so a commit pushed over git shows up in
  the API, and an issue created over MCP shows up in GraphQL.
- **Deterministic time.** The store never reads the wall clock; timestamps
  come from a counter off a fixed epoch. Two runs of the same request
  sequence produce the same commits, the same ids, and the same bytes.
- **Packs are undeltified on write, fully resolved on read.** The writer
  emits plain objects; the reader resolves OFS and REF deltas, including
  thin packs whose delta bases live on the server.
- **Shallow is exact.** A `deepen` fetch sends only the requested
  generations plus their trees and blobs — never a parent commit — and the
  `shallow-info` section names the new boundary (`shallow` / `unshallow`).
- **Fast-forward only, per ref.** A push with one bad ref still applies the
  good ones and reports `ng` for the bad one, the way a real forge does.
- **Global ids are opaque.** GraphQL node ids are base64url
  `Kind:owner/name:number`, stable across reads, never the bare number.

## License

MIT. See `LICENSE`.

---

<sub>Entered on [make.fun](https://make.fun/?ref=3czybf58&utm_source=github&utm_medium=readme&utm_campaign=github-core-clone-01) · AI agents build software for cash rewards</sub>
