// A small GraphQL executor for the documents gh and github-mcp-server actually send:
// viewer, repository lookups, issue and pull-request connections, the four mutations, node(id:),
// __type introspection, and GitHub's operation batching. It is a real parser (not a set of
// string matches), so unknown fields are reported as GraphQL errors, HTTP 200.

import { VIEWER } from './scenario.ts';
import {
  commentGlobalId,
  decodeGlobalId,
  issueGlobalId,
  pullGlobalId,
  repoGlobalId,
  type Issue,
  type PullRequest,
  type Repo,
  type Store,
} from './store.ts';

// ---------------------------------------------------------------------------
// Lexer and parser
// ---------------------------------------------------------------------------

type Token =
  | { kind: 'name'; value: string }
  | { kind: 'int'; value: string }
  | { kind: 'string'; value: string }
  | { kind: 'punct'; value: string }
  | { kind: 'spread' };

function tokenize(source: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  while (i < source.length) {
    const ch = source[i] as string;
    if (/\s/.test(ch) || ch === ',') {
      i += 1;
      continue;
    }
    if (ch === '#') {
      while (i < source.length && source[i] !== '\n') i += 1;
      continue;
    }
    if (ch === '.' && source.slice(i, i + 3) === '...') {
      tokens.push({ kind: 'spread' });
      i += 3;
      continue;
    }
    if ('!$():=@[]{ }|'.includes(ch)) {
      tokens.push({ kind: 'punct', value: ch });
      i += 1;
      continue;
    }
    if (ch === '"') {
      let value = '';
      i += 1;
      while (i < source.length && source[i] !== '"') {
        if (source[i] === '\\' && i + 1 < source.length) {
          const esc = source[i + 1] as string;
          value += esc === 'n' ? '\n' : esc === 't' ? '\t' : esc === 'r' ? '\r' : esc;
          i += 2;
        } else {
          value += source[i];
          i += 1;
        }
      }
      i += 1;
      tokens.push({ kind: 'string', value });
      continue;
    }
    if (/[0-9-]/.test(ch)) {
      let value = '';
      while (i < source.length && /[0-9.]/.test(source[i] as string)) {
        value += source[i];
        i += 1;
      }
      tokens.push({ kind: 'int', value });
      continue;
    }
    if (/[A-Za-z_]/.test(ch)) {
      let value = '';
      while (i < source.length && /[A-Za-z0-9_]/.test(source[i] as string)) {
        value += source[i];
        i += 1;
      }
      tokens.push({ kind: 'name', value });
      continue;
    }
    throw new Error(`unexpected character ${JSON.stringify(ch)} in GraphQL document`);
  }
  return tokens;
}

type ValueNode =
  | { kind: 'variable'; name: string }
  | { kind: 'string'; value: string }
  | { kind: 'int'; value: number }
  | { kind: 'float'; value: number }
  | { kind: 'boolean'; value: boolean }
  | { kind: 'null' }
  | { kind: 'enum'; value: string }
  | { kind: 'list'; values: ValueNode[] }
  | { kind: 'object'; fields: Record<string, ValueNode> };

interface FieldNode {
  kind: 'field';
  alias: string;
  name: string;
  args: Record<string, ValueNode>;
  selection: SelectionNode[];
}

interface FragmentNode {
  kind: 'fragment';
  typeCondition: string;
  selection: SelectionNode[];
}

type SelectionNode = FieldNode | FragmentNode;

interface OperationNode {
  kind: 'query' | 'mutation';
  name: string | null;
  variables: Record<string, { default?: ValueNode }>;
  selection: SelectionNode[];
}

class Parser {
  #tokens: Token[];
  #pos = 0;
  constructor(tokens: Token[]) {
    this.#tokens = tokens;
  }
  #peek(): Token | undefined {
    return this.#tokens[this.#pos];
  }
  #next(): Token {
    const token = this.#tokens[this.#pos];
    this.#pos += 1;
    if (token === undefined) throw new Error('unexpected end of GraphQL document');
    return token;
  }
  #expectPunct(value: string): void {
    const token = this.#next();
    if (token.kind !== 'punct' || token.value !== value) throw new Error(`expected ${value} in GraphQL document`);
  }
  #expectName(value?: string): string {
    const token = this.#next();
    if (token.kind !== 'name') throw new Error('expected a name in GraphQL document');
    if (value !== undefined && token.value !== value) throw new Error(`expected ${value} in GraphQL document`);
    return token.value;
  }

  parseDocument(): OperationNode[] {
    const operations: OperationNode[] = [];
    while (this.#pos < this.#tokens.length) {
      operations.push(this.#parseOperation());
    }
    return operations;
  }

  #parseOperation(): OperationNode {
    let kind: 'query' | 'mutation' = 'query';
    let name: string | null = null;
    const peek = this.#peek();
    if (peek?.kind === 'name' && (peek.value === 'query' || peek.value === 'mutation')) {
      kind = this.#next().value as 'query' | 'mutation';
      const next = this.#peek();
      if (next?.kind === 'name') name = this.#next().value as string;
    } else if (peek?.kind === 'punct' && peek.value === '{') {
      kind = 'query';
    } else {
      throw new Error('expected a query or mutation in GraphQL document');
    }
    const variables: Record<string, { default?: ValueNode }> = {};
    if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '(') {
      this.#expectPunct('(');
      while (!(this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === ')')) {
        this.#expectPunct('$');
        const varName = this.#expectName();
        this.#expectPunct(':');
        this.#parseType();
        const def: { default?: ValueNode } = {};
        if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '=') {
          this.#expectPunct('=');
          def.default = this.#parseValue();
        }
        variables[varName] = def;
      }
      this.#expectPunct(')');
    }
    const selection = this.#parseSelectionSet();
    return { kind, name, variables, selection };
  }

  #parseType(): void {
    const peek = this.#peek();
    if (peek?.kind === 'punct' && peek.value === '[') {
      this.#expectPunct('[');
      this.#parseType();
      this.#expectPunct(']');
    } else {
      this.#expectName();
    }
    if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '!') this.#expectPunct('!');
  }

  #parseSelectionSet(): SelectionNode[] {
    this.#expectPunct('{');
    const selections: SelectionNode[] = [];
    while (!(this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '}')) {
      selections.push(this.#parseSelection());
    }
    this.#expectPunct('}');
    return selections;
  }

  #parseSelection(): SelectionNode {
    const peek = this.#peek();
    if (peek?.kind === 'spread') {
      this.#next();
      this.#expectName('on');
      const typeCondition = this.#expectName();
      const selection = this.#parseSelectionSet();
      return { kind: 'fragment', typeCondition, selection };
    }
    let alias = this.#expectName();
    let name = alias;
    if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === ':') {
      this.#expectPunct(':');
      name = this.#expectName();
    }
    const args: Record<string, ValueNode> = {};
    if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '(') {
      this.#expectPunct('(');
      while (!(this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === ')')) {
        const argName = this.#expectName();
        this.#expectPunct(':');
        args[argName] = this.#parseValue();
      }
      this.#expectPunct(')');
    }
    let selection: SelectionNode[] = [];
    if (this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '{') {
      selection = this.#parseSelectionSet();
    }
    return { kind: 'field', alias, name, args, selection };
  }

  #parseValue(): ValueNode {
    const token = this.#next();
    if (token.kind === 'punct' && token.value === '$') return { kind: 'variable', name: this.#expectName() };
    if (token.kind === 'punct' && token.value === '[') {
      const values: ValueNode[] = [];
      while (!(this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === ']')) {
        values.push(this.#parseValue());
      }
      this.#expectPunct(']');
      return { kind: 'list', values };
    }
    if (token.kind === 'punct' && token.value === '{') {
      const fields: Record<string, ValueNode> = {};
      while (!(this.#peek()?.kind === 'punct' && (this.#peek() as { value: string }).value === '}')) {
        const name = this.#expectName();
        this.#expectPunct(':');
        fields[name] = this.#parseValue();
      }
      this.#expectPunct('}');
      return { kind: 'object', fields };
    }
    if (token.kind === 'string') return { kind: 'string', value: token.value };
    if (token.kind === 'int') {
      return token.value.includes('.') ? { kind: 'float', value: Number(token.value) } : { kind: 'int', value: Number(token.value) };
    }
    if (token.kind === 'name') {
      if (token.value === 'true') return { kind: 'boolean', value: true };
      if (token.value === 'false') return { kind: 'boolean', value: false };
      if (token.value === 'null') return { kind: 'null' };
      return { kind: 'enum', value: token.value };
    }
    throw new Error('unexpected value in GraphQL document');
  }
}

function valueOf(node: ValueNode, variables: Record<string, unknown>): unknown {
  switch (node.kind) {
    case 'variable':
      return variables[node.name];
    case 'string':
    case 'int':
    case 'float':
    case 'boolean':
      return node.value;
    case 'null':
      return null;
    case 'enum':
      return node.value;
    case 'list':
      return node.values.map((value) => valueOf(value, variables));
    case 'object': {
      const out: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(node.fields)) out[key] = valueOf(value, variables);
      return out;
    }
  }
}

// ---------------------------------------------------------------------------
// Schema knowledge (the fields the suite's documents and probes can name)
// ---------------------------------------------------------------------------

const TYPE_FIELDS: Record<string, string[]> = {
  Issue: ['id', 'number', 'title', 'state', 'body', 'createdAt', 'updatedAt', 'author', 'labels', 'comments', 'url', 'closedAt', 'repository'],
  PullRequest: ['id', 'number', 'headRefName', 'baseRefName', 'mergeable', 'state', 'merged', 'files', 'title', 'body', 'author', 'createdAt', 'updatedAt', 'baseRef', 'headRef', 'mergedAt', 'mergeCommit', 'url', 'headRefOid', 'baseRefOid'],
  Repository: ['id', 'databaseId', 'name', 'nameWithOwner', 'owner', 'defaultBranchRef', 'viewerPermission', 'hasIssuesEnabled', 'issue', 'issues', 'pullRequests', 'pullRequest', 'description', 'createdAt', 'updatedAt', 'url', 'defaultBranch', 'isPrivate', 'fork'],
  SearchType: [],
};

const SEARCH_TYPE_VALUES = ['ISSUE', 'PULL_REQUEST', 'REPOSITORY', 'USER', 'DISCUSSION', 'COMMIT', 'WIKI', 'CODE', 'REGISTRY'];

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

interface ExecContext {
  store: Store;
  variables: Record<string, unknown>;
  errors: Array<{ message: string }>;
}

function cursorFor(number: number): string {
  return Buffer.from(`cursor:${number}`, 'utf8').toString('base64');
}

function numberFromCursor(cursor: unknown): number | null {
  if (typeof cursor !== 'string' || cursor === '') return null;
  try {
    const text = Buffer.from(cursor, 'base64').toString('utf8');
    const match = /^cursor:(\d+)$/.exec(text);
    return match === null ? null : Number(match[1]);
  } catch {
    return null;
  }
}

function issueState(issue: Issue): string {
  return issue.state === 'open' ? 'OPEN' : 'CLOSED';
}

function pullState(pull: PullRequest): string {
  return pull.state === 'open' ? 'OPEN' : 'CLOSED';
}

function executeSelection(parentType: string, parentValue: unknown, selections: SelectionNode[], ctx: ExecContext): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const selection of selections) {
    if (selection.kind === 'fragment') {
      if (selection.typeCondition === parentType || (selection.typeCondition === 'Repository' && parentType === 'Repository')) {
        Object.assign(out, executeSelection(parentType, parentValue, selection.selection, ctx));
      }
      continue;
    }
    const field = selection;
    const value = resolveField(parentType, parentValue, field, ctx);
    out[field.alias] = value;
  }
  return out;
}

function unknownField(parentType: string, fieldName: string, ctx: ExecContext): null {
  ctx.errors.push({ message: `Cannot query field "${fieldName}" on type "${parentType}".` });
  return null;
}

function resolveField(parentType: string, parentValue: unknown, field: FieldNode, ctx: ExecContext): unknown {
  const args: Record<string, unknown> = {};
  for (const [key, node] of Object.entries(field.args)) args[key] = valueOf(node, ctx.variables);

  if (parentType === 'Query') {
    if (field.name === 'viewer') {
      return executeSelection('User', { login: VIEWER.login }, field.selection, ctx);
    }
    if (field.name === 'repository') {
      const repo = findRepoIn(ctx, args.owner, args.name);
      if (repo === null) return null;
      return executeSelection('Repository', repo, field.selection, ctx);
    }
    if (field.name === 'node') {
      const decoded = typeof args.id === 'string' ? decodeGlobalId(args.id) : null;
      if (decoded === null || decoded.kind !== 'Repository') return null;
      const repo = ctx.store.getRepo(decoded.owner, decoded.name);
      if (repo === undefined) return null;
      return executeSelection('Repository', repo, field.selection, ctx);
    }
    if (field.name === '__type') {
      return introspectType(args.name, field.selection, ctx);
    }
    if (field.name === '__schema') {
      return executeSelection('__Schema', {}, field.selection, ctx);
    }
    return unknownField('Query', field.name, ctx);
  }

  if (parentType === 'Mutation') {
    if (field.name === 'createIssue') return executeSelection('CreateIssuePayload', createIssue(ctx, args), field.selection, ctx);
    if (field.name === 'closeIssue') return executeSelection('CloseIssuePayload', closeIssue(ctx, args), field.selection, ctx);
    if (field.name === 'createPullRequest') return executeSelection('CreatePullRequestPayload', createPullRequest(ctx, args), field.selection, ctx);
    if (field.name === 'mergePullRequest') return executeSelection('MergePullRequestPayload', mergePullRequest(ctx, args), field.selection, ctx);
    if (field.name === 'addComment') return executeSelection('AddCommentPayload', addComment(ctx, args), field.selection, ctx);
    return unknownField('Mutation', field.name, ctx);
  }

  if (parentType === 'User') {
    const user = parentValue as { login: string };
    if (field.name === 'login') return user.login;
    if (field.name === 'id') return Buffer.from(`User:${user.login}`, 'utf8').toString('base64url');
    if (field.name === 'name') return VIEWER.name;
    if (field.name === 'email') return VIEWER.email;
    return unknownField('User', field.name, ctx);
  }

  if (parentType === 'Repository') {
    const repo = parentValue as Repo;
    switch (field.name) {
      case 'id':
        return repoGlobalId(repo);
      case 'databaseId':
        return repo.id;
      case 'name':
        return repo.name;
      case 'nameWithOwner':
        return `${repo.owner}/${repo.name}`;
      case 'owner':
        return executeSelection('User', { login: repo.owner }, field.selection, ctx);
      case 'defaultBranchRef': {
        const tip = repo.refs.get(`refs/heads/${repo.defaultBranch}`);
        if (tip === undefined) return null;
        return executeSelection('Ref', { name: repo.defaultBranch }, field.selection, ctx);
      }
      case 'viewerPermission':
        return 'ADMIN';
      case 'hasIssuesEnabled':
        return true;
      case 'description':
        return repo.description;
      case 'isPrivate':
        return repo.private;
      case 'url':
        return `https://github.com/${repo.owner}/${repo.name}`;
      case 'issues':
        return issuesConnection(repo, args, field.selection, ctx);
      case 'issue': {
        const issue = repo.issues.get(Number(args.number));
        if (issue === undefined) return null;
        return executeSelection('Issue', { repo, issue }, field.selection, ctx);
      }
      case 'pullRequests':
        return pullsConnection(repo, args, field.selection, ctx);
      case 'pullRequest': {
        const pull = repo.pulls.get(Number(args.number));
        if (pull === undefined) return null;
        return executeSelection('PullRequest', { repo, pull }, field.selection, ctx);
      }
      default:
        return unknownField('Repository', field.name, ctx);
    }
  }

  if (parentType === 'Ref') {
    const ref = parentValue as { name: string };
    if (field.name === 'name') return ref.name;
    return unknownField('Ref', field.name, ctx);
  }

  if (parentType === 'Issue') {
    const { repo, issue } = parentValue as { repo: Repo; issue: Issue };
    switch (field.name) {
      case 'id':
        return issueGlobalId(repo, issue);
      case 'number':
        return issue.number;
      case 'title':
        return issue.title;
      case 'state':
        return issueState(issue);
      case 'body':
        return issue.body;
      case 'createdAt':
        return issue.createdAt;
      case 'updatedAt':
        return issue.updatedAt;
      default:
        return unknownField('Issue', field.name, ctx);
    }
  }

  if (parentType === 'PullRequest') {
    const { repo, pull } = parentValue as { repo: Repo; pull: PullRequest };
    switch (field.name) {
      case 'id':
        return pullGlobalId(repo, pull);
      case 'number':
        return pull.number;
      case 'headRefName':
        return pull.headRef;
      case 'baseRefName':
        return pull.baseRef;
      case 'mergeable':
        return ctx.store.pullMergeable(repo, pull);
      case 'state':
        return pullState(pull);
      case 'merged':
        return pull.merged;
      case 'title':
        return pull.title;
      case 'body':
        return pull.body;
      case 'files': {
        const files = ctx.store.pullFiles(repo, pull);
        const first = typeof args.first === 'number' ? (args.first as number) : files.length;
        const nodesField = field.selection.find((sel) => sel.kind === 'field' && sel.name === 'nodes');
        const nodesSelection = nodesField?.kind === 'field' ? nodesField.selection : [];
        return { nodes: files.slice(0, first).map((file) => executeSelection('PullRequestFile', { path: file.path }, nodesSelection, ctx)) };
      }
      default:
        return unknownField('PullRequest', field.name, ctx);
    }
  }

  if (parentType === 'PullRequestFile') {
    const file = parentValue as { path: string };
    if (field.name === 'path') return file.path;
    return unknownField('PullRequestFile', field.name, ctx);
  }

  if (parentType === 'CreateIssuePayload' || parentType === 'CloseIssuePayload') {
    const payload = parentValue as { issue: { repo: Repo; issue: Issue } | null };
    if (field.name === 'issue') {
      if (payload.issue === null) return null;
      return executeSelection('Issue', payload.issue, field.selection, ctx);
    }
    return unknownField(parentType, field.name, ctx);
  }

  if (parentType === 'CreatePullRequestPayload' || parentType === 'MergePullRequestPayload') {
    const payload = parentValue as { pullRequest: { repo: Repo; pull: PullRequest } | null };
    if (field.name === 'pullRequest') {
      if (payload.pullRequest === null) return null;
      return executeSelection('PullRequest', payload.pullRequest, field.selection, ctx);
    }
    return unknownField(parentType, field.name, ctx);
  }

  if (parentType === 'AddCommentPayload') {
    const payload = parentValue as { commentEdge: { node: { id: string; body: string } } | null };
    if (field.name === 'commentEdge') {
      if (payload.commentEdge === null) return null;
      const nodeField = field.selection.find((sel) => sel.kind === 'field' && sel.name === 'node');
      const node = nodeField?.kind === 'field' ? executeSelection('Comment', payload.commentEdge.node, nodeField.selection, ctx) : null;
      return { node };
    }
    return unknownField(parentType, field.name, ctx);
  }

  if (parentType === 'Comment') {
    const comment = parentValue as { id: string; body: string };
    if (field.name === 'id') return comment.id;
    if (field.name === 'body') return comment.body;
    return unknownField('Comment', field.name, ctx);
  }

  if (parentType === '__Type') {
    const type = parentValue as { name: string };
    if (field.name === 'name') return type.name;
    if (field.name === 'fields') {
      const names = TYPE_FIELDS[type.name] ?? [];
      return names.map((name) => ({ name }));
    }
    if (field.name === 'enumValues') {
      if (type.name === 'SearchType') return SEARCH_TYPE_VALUES.map((name) => ({ name }));
      return [];
    }
    return unknownField('__Type', field.name, ctx);
  }

  return unknownField(parentType, field.name, ctx);
}

function introspectType(name: unknown, selection: SelectionNode[], ctx: ExecContext): Record<string, unknown> | null {
  if (typeof name !== 'string') return null;
  const known = ['Issue', 'PullRequest', 'Repository', 'SearchType', 'User', 'Query', 'Mutation'];
  if (!known.includes(name)) return null;
  return executeSelection('__Type', { name }, selection, ctx);
}

function findRepoIn(ctx: ExecContext, owner: unknown, name: unknown): Repo | null {
  if (owner !== VIEWER.login || typeof name !== 'string') return null;
  return ctx.store.getRepo(VIEWER.login, name) ?? null;
}

function issuesConnection(repo: Repo, args: Record<string, unknown>, selection: SelectionNode[], ctx: ExecContext): Record<string, unknown> {
  let issues = [...repo.issues.values()].sort((a, b) => a.seq - b.seq);
  if (Array.isArray(args.states)) {
    const wanted = new Set((args.states as unknown[]).map((state) => String(state)));
    issues = issues.filter((issue) => wanted.has(issueState(issue)));
  }
  if (args.orderBy !== undefined && typeof args.orderBy === 'object' && args.orderBy !== null) {
    const orderBy = args.orderBy as Record<string, unknown>;
    if (orderBy.field === 'CREATED_AT') {
      issues.sort((a, b) => (orderBy.direction === 'DESC' ? b.seq - a.seq : a.seq - b.seq));
    }
  }
  const afterNumber = numberFromCursor(args.after);
  if (afterNumber !== null) issues = issues.filter((issue) => issue.seq > afterNumber);
  const first = typeof args.first === 'number' ? (args.first as number) : issues.length;
  const page = issues.slice(0, first);
  const hasNextPage = issues.length > page.length;
  const endCursor = page.length > 0 ? cursorFor(page[page.length - 1]?.seq ?? 0) : null;
  const out: Record<string, unknown> = {};
  for (const sel of selection) {
    if (sel.kind !== 'field') continue;
    if (sel.name === 'nodes') out.nodes = page.map((issue) => executeSelection('Issue', { repo, issue }, sel.selection, ctx));
    else if (sel.name === 'pageInfo') out.pageInfo = { hasNextPage, endCursor };
    else if (sel.name === 'totalCount') out.totalCount = issues.length;
  }
  return out;
}

function pullsConnection(repo: Repo, args: Record<string, unknown>, selection: SelectionNode[], ctx: ExecContext): Record<string, unknown> {
  let pulls = [...repo.pulls.values()].sort((a, b) => b.seq - a.seq);
  if (Array.isArray(args.states)) {
    const wanted = new Set((args.states as unknown[]).map((state) => String(state)));
    pulls = pulls.filter((pull) => wanted.has(pullState(pull)));
  }
  const first = typeof args.first === 'number' ? (args.first as number) : pulls.length;
  const page = pulls.slice(0, first);
  const out: Record<string, unknown> = {};
  for (const sel of selection) {
    if (sel.kind !== 'field') continue;
    if (sel.name === 'nodes') out.nodes = page.map((pull) => executeSelection('PullRequest', { repo, pull }, sel.selection, ctx));
    else if (sel.name === 'pageInfo') out.pageInfo = { hasNextPage: pulls.length > page.length, endCursor: page.length > 0 ? cursorFor(page[page.length - 1]?.seq ?? 0) : null };
  }
  return out;
}

// ---------------------------------------------------------------------------
// Mutations
// ---------------------------------------------------------------------------

function createIssue(ctx: ExecContext, args: Record<string, unknown>): { issue: { repo: Repo; issue: Issue } | null } {
  const input = (args.input ?? {}) as Record<string, unknown>;
  const decoded = typeof input.repositoryId === 'string' ? decodeGlobalId(input.repositoryId) : null;
  if (decoded === null || decoded.kind !== 'Repository') return { issue: null };
  const repo = ctx.store.getRepo(decoded.owner, decoded.name);
  if (repo === undefined) return { issue: null };
  repo.issueSeq += 1;
  const stamp = ctx.store.stamp();
  const issue: Issue = {
    id: ctx.store.nextId(),
    number: repo.issueSeq,
    title: typeof input.title === 'string' ? input.title : '',
    body: typeof input.body === 'string' ? input.body : '',
    state: 'open',
    labels: [],
    comments: [],
    createdAt: stamp,
    updatedAt: stamp,
    seq: repo.issueSeq,
  };
  repo.issues.set(issue.number, issue);
  return { issue: { repo, issue } };
}

function closeIssue(ctx: ExecContext, args: Record<string, unknown>): { issue: { repo: Repo; issue: Issue } | null } {
  const input = (args.input ?? {}) as Record<string, unknown>;
  const decoded = typeof input.issueId === 'string' ? decodeGlobalId(input.issueId) : null;
  if (decoded === null || decoded.kind !== 'Issue') return { issue: null };
  const repo = ctx.store.getRepo(decoded.owner, decoded.name);
  const issue = repo?.issues.get(decoded.number);
  if (repo === undefined || issue === undefined) return { issue: null };
  issue.state = 'closed';
  issue.updatedAt = ctx.store.stamp();
  return { issue: { repo, issue } };
}

function createPullRequest(ctx: ExecContext, args: Record<string, unknown>): { pullRequest: { repo: Repo; pull: PullRequest } | null } {
  const input = (args.input ?? {}) as Record<string, unknown>;
  const decoded = typeof input.repositoryId === 'string' ? decodeGlobalId(input.repositoryId) : null;
  if (decoded === null || decoded.kind !== 'Repository') return { pullRequest: null };
  const repo = ctx.store.getRepo(decoded.owner, decoded.name);
  if (repo === undefined) return { pullRequest: null };
  const headRef = typeof input.headRefName === 'string' ? input.headRefName : '';
  const baseRef = typeof input.baseRefName === 'string' ? input.baseRefName : repo.defaultBranch;
  const headSha = repo.refs.get(`refs/heads/${headRef}`);
  const baseSha = repo.refs.get(`refs/heads/${baseRef}`);
  if (headSha === undefined || baseSha === undefined) return { pullRequest: null };
  repo.pullSeq += 1;
  const stamp = ctx.store.stamp();
  const pull: PullRequest = {
    id: ctx.store.nextId(),
    number: repo.pullSeq,
    title: typeof input.title === 'string' ? input.title : '',
    body: typeof input.body === 'string' ? input.body : '',
    state: 'open',
    headRef,
    headSha,
    baseRef,
    baseSha,
    merged: false,
    mergedAt: null,
    mergeCommitSha: null,
    createdAt: stamp,
    updatedAt: stamp,
    seq: repo.pullSeq,
  };
  repo.pulls.set(pull.number, pull);
  return { pullRequest: { repo, pull } };
}

function mergePullRequest(ctx: ExecContext, args: Record<string, unknown>): { pullRequest: { repo: Repo; pull: PullRequest } | null } {
  const input = (args.input ?? {}) as Record<string, unknown>;
  const decoded = typeof input.pullRequestId === 'string' ? decodeGlobalId(input.pullRequestId) : null;
  if (decoded === null || decoded.kind !== 'PullRequest') return { pullRequest: null };
  const repo = ctx.store.getRepo(decoded.owner, decoded.name);
  const pull = repo?.pulls.get(decoded.number);
  if (repo === undefined || pull === undefined || pull.state !== 'open') return { pullRequest: null };
  const merged = ctx.store.mergePull(repo, pull);
  if (merged === null) return { pullRequest: { repo, pull } };
  pull.merged = true;
  pull.state = 'closed';
  pull.mergedAt = ctx.store.stamp();
  pull.mergeCommitSha = merged.sha;
  pull.updatedAt = ctx.store.stamp();
  return { pullRequest: { repo, pull } };
}

function addComment(ctx: ExecContext, args: Record<string, unknown>): { commentEdge: { node: { id: string; body: string } } | null } {
  const input = (args.input ?? {}) as Record<string, unknown>;
  const decoded = typeof input.subjectId === 'string' ? decodeGlobalId(input.subjectId) : null;
  if (decoded === null || decoded.kind !== 'Issue') return { commentEdge: null };
  const repo = ctx.store.getRepo(decoded.owner, decoded.name);
  const issue = repo?.issues.get(decoded.number);
  if (repo === undefined || issue === undefined) return { commentEdge: null };
  repo.commentSeq += 1;
  const comment = { id: ctx.store.nextId(), body: typeof input.body === 'string' ? input.body : '', createdAt: ctx.store.stamp() };
  issue.comments.push(comment);
  return { commentEdge: { node: { id: commentGlobalId(repo, issue, comment), body: comment.body } } };
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

export interface GraphQLResult {
  data: unknown;
  errors?: Array<{ message: string }>;
}

function executeOperation(operation: OperationNode, variables: Record<string, unknown>, store: Store): GraphQLResult {
  const ctx: ExecContext = { store, variables: { ...variables }, errors: [] };
  // Apply variable defaults.
  for (const [name, def] of Object.entries(operation.variables)) {
    if (ctx.variables[name] === undefined && def.default !== undefined) {
      ctx.variables[name] = valueOf(def.default, ctx.variables);
    }
  }
  const rootType = operation.kind === 'mutation' ? 'Mutation' : 'Query';
  const data = executeSelection(rootType, null, operation.selection, ctx);
  const result: GraphQLResult = { data };
  if (ctx.errors.length > 0) result.errors = ctx.errors;
  return result;
}

/**
 * Handle one POST /api/graphql body: a single operation object, or an array of them (GitHub's
 * operation batching), answered in order.
 */
export function handleGraphQL(body: unknown, store: Store): { status: number; value: unknown } {
  const isBatch = Array.isArray(body);
  const operations = isBatch ? body : [body];
  const results: unknown[] = [];
  for (const item of operations) {
    if (typeof item !== 'object' || item === null || typeof (item as Record<string, unknown>).query !== 'string') {
      results.push({ errors: [{ message: 'A GraphQL operation needs a query string.' }] });
      continue;
    }
    const record = item as Record<string, unknown>;
    const query = record.query as string;
    const variables = (record.variables ?? {}) as Record<string, unknown>;
    try {
      const parsed = new Parser(tokenize(query)).parseDocument();
      if (parsed.length === 0) {
        results.push({ errors: [{ message: 'The document holds no operation.' }] });
        continue;
      }
      if (parsed.length > 1) {
        // Several operations in one document string: run each, in order.
        results.push(parsed.map((operation) => executeOperation(operation, variables, store)));
        continue;
      }
      results.push(executeOperation(parsed[0] as OperationNode, variables, store));
    } catch (err) {
      results.push({ errors: [{ message: err instanceof Error ? err.message : 'GraphQL parse error' }] });
    }
  }
  return { status: 200, value: isBatch ? results : results[0] };
}
