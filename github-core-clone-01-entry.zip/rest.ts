// The GitHub REST v3 surface: repositories, branches, commits, contents, labels, issues,
// comments and pull requests, over the in-memory store. Every reply is JSON with a
// X-GitHub-Request-Id header; unknown routes are JSON 404s; malformed JSON is a 400.

import { VIEWER } from './scenario.ts';
import {
  flattenTree,
  hashObject,
  parseCommit,
  parseTree,
  type Issue,
  type PullRequest,
  type Repo,
  type Store,
} from './store.ts';

export interface HandlerResult {
  status: number;
  contentType: string;
  headers?: Record<string, string>;
  body: Buffer;
}

export function jsonResult(status: number, value: unknown, headers: Record<string, string> = {}): HandlerResult {
  const text = `${JSON.stringify(value)}\n`;
  return { status, contentType: 'application/json; charset=utf-8', headers, body: Buffer.from(text, 'utf8') };
}

export function jsonError(status: number, message: string): HandlerResult {
  return jsonResult(status, { message });
}

const SHA40 = /^[0-9a-f]{40}$/i;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function splitPath(pathname: string): string[] {
  return pathname.split('/').filter((part) => part !== '');
}

function decodeSegment(segment: string): string {
  try {
    return decodeURIComponent(segment);
  } catch {
    return segment;
  }
}

/** The viewer's repository, or null when the owner is not the viewer or the repo is missing. */
function findRepo(store: Store, owner: string, name: string): Repo | null {
  if (owner !== VIEWER.login) return null;
  return store.getRepo(owner, name) ?? null;
}

function repoJson(repo: Repo): Record<string, unknown> {
  return {
    id: repo.id,
    node_id: `R_${repo.id}`,
    name: repo.name,
    full_name: `${repo.owner}/${repo.name}`,
    owner: { login: repo.owner, id: VIEWER.id, type: 'User' },
    private: repo.private,
    description: repo.description,
    default_branch: repo.defaultBranch,
    html_url: `https://github.com/${repo.owner}/${repo.name}`,
    clone_url: `https://github.com/${repo.owner}/${repo.name}.git`,
    created_at: repo.createdAt,
    updated_at: repo.createdAt,
    pushed_at: repo.createdAt,
    language: null,
    has_issues: true,
    has_projects: false,
    has_wiki: false,
    forks_count: 0,
    stargazers_count: 0,
    watchers_count: 0,
    open_issues_count: [...repo.issues.values()].filter((issue) => issue.state === 'open').length,
  };
}

function issueJson(repo: Repo, issue: Issue): Record<string, unknown> {
  return {
    id: issue.id,
    node_id: `I_${repo.id}_${issue.number}`,
    number: issue.number,
    title: issue.title,
    body: issue.body,
    state: issue.state,
    labels: issue.labels.map((name) => {
      const label = repo.labels.get(name);
      return { name, color: label?.color ?? 'ededed' };
    }),
    user: { login: VIEWER.login, id: VIEWER.id, type: 'User' },
    created_at: issue.createdAt,
    updated_at: issue.updatedAt,
    comments: issue.comments.length,
    html_url: `https://github.com/${repo.owner}/${repo.name}/issues/${issue.number}`,
    url: `/api/v3/repos/${repo.owner}/${repo.name}/issues/${issue.number}`,
  };
}

function pullJson(repo: Repo, pull: PullRequest): Record<string, unknown> {
  return {
    id: pull.id,
    node_id: `PR_${repo.id}_${pull.number}`,
    number: pull.number,
    title: pull.title,
    body: pull.body,
    state: pull.state,
    head: { ref: pull.headRef, sha: pull.headSha, label: `${repo.owner}:${pull.headRef}` },
    base: { ref: pull.baseRef, sha: pull.baseSha, label: `${repo.owner}:${pull.baseRef}` },
    merged: pull.merged,
    merged_at: pull.mergedAt,
    merge_commit_sha: pull.mergeCommitSha,
    user: { login: VIEWER.login, id: VIEWER.id, type: 'User' },
    created_at: pull.createdAt,
    updated_at: pull.updatedAt,
    html_url: `https://github.com/${repo.owner}/${repo.name}/pull/${pull.number}`,
    url: `/api/v3/repos/${repo.owner}/${repo.name}/pulls/${pull.number}`,
    draft: false,
  };
}

function parsePagination(query: URLSearchParams): { page: number; perPage: number } {
  const page = Math.max(1, Number(query.get('page') ?? '1') || 1);
  const perPage = Math.min(100, Math.max(1, Number(query.get('per_page') ?? '30') || 30));
  return { page, perPage };
}

function pageOf<T>(items: readonly T[], page: number, perPage: number): { items: T[]; hasNext: boolean; total: number } {
  const start = (page - 1) * perPage;
  return { items: items.slice(start, start + perPage), hasNext: start + perPage < items.length, total: items.length };
}

function linkHeader(base: string, pathname: string, query: URLSearchParams, page: number, perPage: number, hasNext: boolean): string | null {
  if (!hasNext) return null;
  const next = new URLSearchParams(query);
  next.set('page', String(page + 1));
  next.set('per_page', String(perPage));
  return `<${base}${pathname}?${next.toString()}>; rel="next"`;
}

/** The commits reachable from `tip`, newest first (parents after children, BFS by depth). */
function listCommits(store: Store, repo: Repo, tip: string): Array<{ sha: string; message: string; author: string; committer: string; parents: string[] }> {
  const lookup = store.lookup(repo);
  const out: Array<{ sha: string; message: string; author: string; committer: string; parents: string[] }> = [];
  const seen = new Set<string>();
  const queue = [tip];
  while (queue.length > 0) {
    const oid = queue.shift() as string;
    if (seen.has(oid)) continue;
    seen.add(oid);
    const object = lookup(oid);
    if (object === undefined || object.type !== 'commit') continue;
    const commit = parseCommit(object.data);
    out.push({ sha: oid, message: commit.message, author: commit.author, committer: commit.committer, parents: commit.parents });
    for (const parent of commit.parents) queue.push(parent);
  }
  return out;
}

export function handleRest(
  method: string,
  pathname: string,
  query: URLSearchParams,
  jsonBody: unknown,
  store: Store,
  baseUrl: string,
): HandlerResult {
  const parts = splitPath(pathname).map(decodeSegment);
  // parts[0] is 'api', parts[1] is 'v3'.
  const rest = parts.slice(2);

  // GET /api/v3/ — the API root.
  if (rest.length === 0) {
    if (method !== 'GET') return jsonError(404, 'Not Found');
    return jsonResult(200, { current_user_url: '/api/v3/user', rate_limit_url: '/api/v3/rate_limit' }, { 'x-oauth-scopes': 'repo, read:org' });
  }

  // GET /api/v3/meta
  if (rest.length === 1 && rest[0] === 'meta') {
    if (method !== 'GET') return jsonError(404, 'Not Found');
    return jsonResult(200, { installed_version: '1.0.0', verifiable_password_authentication: false });
  }

  // GET /api/v3/user
  if (rest.length === 1 && rest[0] === 'user') {
    if (method !== 'GET') return jsonError(404, 'Not Found');
    return jsonResult(200, { login: VIEWER.login, id: VIEWER.id, name: VIEWER.name, email: VIEWER.email, type: 'User' });
  }

  // /api/v3/user/repos
  if (rest.length === 2 && rest[0] === 'user' && rest[1] === 'repos') {
    if (method === 'GET') {
      const { page, perPage } = parsePagination(query);
      const repos = store.listRepos(VIEWER.login);
      const { items, hasNext } = pageOf(repos, page, perPage);
      const headers: Record<string, string> = {};
      const link = linkHeader(baseUrl, pathname, query, page, perPage, hasNext);
      if (link !== null) headers.link = link;
      return jsonResult(200, items.map(repoJson), headers);
    }
    if (method === 'POST') {
      if (!isRecord(jsonBody) || typeof jsonBody.name !== 'string' || jsonBody.name === '') {
        return jsonError(422, 'name is required');
      }
      const name = jsonBody.name as string;
      if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/.test(name)) return jsonError(422, 'invalid repository name');
      const existing = store.getRepo(VIEWER.login, name);
      if (existing !== undefined) return jsonError(422, 'Repository creation failed. name already exists on this account');
      const repo = store.createRepo(VIEWER.login, name, {
        description: typeof jsonBody.description === 'string' ? (jsonBody.description as string) : '',
        private: jsonBody.private === true,
        defaultBranch: typeof jsonBody.default_branch === 'string' ? (jsonBody.default_branch as string) : 'main',
      });
      if (repo === null) return jsonError(422, 'Repository creation failed');
      return jsonResult(201, repoJson(repo));
    }
    return jsonError(404, 'Not Found');
  }

  // /api/v3/repos/{owner}/{name}/...
  if (rest.length >= 3 && rest[0] === 'repos') {
    const owner = rest[1] as string;
    const name = rest[2] as string;
    const repo = findRepo(store, owner, name);
    const tail = rest.slice(3);

    if (tail.length === 0) {
      if (method === 'GET') {
        if (repo === null) return jsonError(404, 'Not Found');
        return jsonResult(200, repoJson(repo));
      }
      if (method === 'PATCH') {
        if (repo === null) return jsonError(404, 'Not Found');
        if (isRecord(jsonBody) && typeof jsonBody.description === 'string') repo.description = jsonBody.description as string;
        return jsonResult(200, repoJson(repo));
      }
      if (method === 'DELETE') {
        if (repo === null) return jsonError(404, 'Not Found');
        store.deleteRepo(owner, name);
        return { status: 204, contentType: 'application/json; charset=utf-8', body: Buffer.alloc(0) };
      }
      return jsonError(404, 'Not Found');
    }

    if (repo === null) return jsonError(404, 'Not Found');

    // GET /repos/{o}/{r}/branches
    if (tail.length === 1 && tail[0] === 'branches' && method === 'GET') {
      const branches: Array<Record<string, unknown>> = [];
      for (const [ref, sha] of [...repo.refs.entries()].sort()) {
        if (!ref.startsWith('refs/heads/')) continue;
        branches.push({ name: ref.slice('refs/heads/'.length), commit: { sha } });
      }
      return jsonResult(200, branches);
    }

    // GET /repos/{o}/{r}/commits[?sha=]
    if (tail.length === 1 && tail[0] === 'commits' && method === 'GET') {
      const ref = query.get('sha') ?? undefined;
      const tip = store.resolveRef(repo, ref);
      if (tip === null) return jsonResult(200, []);
      const commits = listCommits(store, repo, tip);
      return jsonResult(
        200,
        commits.map((commit) => ({
          sha: commit.sha,
          commit: {
            // GitHub presents the message without the trailing newline the object stores.
            message: commit.message.replace(/\r?\n$/, ''),
            author: { name: commit.author.split(' <')[0] ?? '', email: '', date: '' },
            committer: { name: commit.committer.split(' <')[0] ?? '', email: '', date: '' },
          },
          parents: commit.parents.map((sha) => ({ sha })),
        })),
      );
    }

    // POST /repos/{o}/{r}/git/refs — create a branch or tag ref.
    if (tail.length === 2 && tail[0] === 'git' && tail[1] === 'refs' && method === 'POST') {
      if (!isRecord(jsonBody) || typeof jsonBody.ref !== 'string' || typeof jsonBody.sha !== 'string') {
        return jsonError(422, 'ref and sha are required');
      }
      const ref = jsonBody.ref as string;
      const sha = jsonBody.sha as string;
      if (!ref.startsWith('refs/') || !SHA40.test(sha)) return jsonError(422, 'invalid ref or sha');
      if (repo.refs.has(ref)) return jsonError(422, 'Reference already exists');
      const object = repo.objects.get(sha);
      if (object === undefined) return jsonError(422, 'Object does not exist');
      repo.refs.set(ref, sha);
      return jsonResult(201, { ref, object: { sha } });
    }

    // /repos/{o}/{r}/contents/{path...}
    if (tail.length >= 2 && tail[0] === 'contents') {
      const filePath = tail.slice(1).join('/');
      if (method === 'PUT') {
        if (!isRecord(jsonBody) || typeof jsonBody.message !== 'string' || typeof jsonBody.content !== 'string') {
          return jsonError(422, 'message and content are required');
        }
        const branch = typeof jsonBody.branch === 'string' ? (jsonBody.branch as string) : repo.defaultBranch;
        const refName = `refs/heads/${branch}`;
        const tip = repo.refs.get(refName) ?? null;
        let currentSha: string | null = null;
        if (tip !== null) {
          const tree = parseCommit(repo.objects.get(tip)?.data ?? Buffer.alloc(0)).tree;
          const flat = flattenTree(store.lookup(repo), tree);
          currentSha = flat.get(filePath)?.oid ?? null;
        }
        const requestedSha = typeof jsonBody.sha === 'string' ? (jsonBody.sha as string) : null;
        if (requestedSha !== null && currentSha !== null && requestedSha.toLowerCase() !== currentSha.toLowerCase()) {
          return jsonError(409, 'sha does not match the current blob');
        }
        const isUpdate = currentSha !== null;
        let content: Buffer;
        try {
          content = Buffer.from(jsonBody.content as string, 'base64');
        } catch {
          return jsonError(422, 'content is not valid base64');
        }
        const { commitSha, contentSha } = store.commitFile(repo, branch, filePath, content, jsonBody.message as string);
        return jsonResult(isUpdate ? 200 : 201, {
          content: { name: filePath.split('/').pop() ?? filePath, path: filePath, sha: contentSha, size: content.length, encoding: 'base64' },
          commit: { sha: commitSha },
        });
      }
      if (method === 'GET') {
        const ref = query.get('ref') ?? undefined;
        const tip = store.resolveRef(repo, ref);
        if (tip === null) return jsonError(404, 'Not Found');
        const tree = parseCommit(repo.objects.get(tip)?.data ?? Buffer.alloc(0)).tree;
        const flat = flattenTree(store.lookup(repo), tree);
        const entry = flat.get(filePath);
        if (entry !== undefined) {
          const object = repo.objects.get(entry.oid);
          const data = object?.data ?? Buffer.alloc(0);
          return jsonResult(200, {
            type: 'file',
            encoding: 'base64',
            size: data.length,
            name: filePath.split('/').pop() ?? filePath,
            path: filePath,
            content: data.toString('base64'),
            sha: entry.oid,
          });
        }
        // A directory: its immediate children.
        const prefix = `${filePath}/`;
        const children = new Map<string, { type: string; name: string; path: string; sha: string }>();
        for (const [path, item] of flat) {
          if (!path.startsWith(prefix)) continue;
          const rest2 = path.slice(prefix.length);
          const first = rest2.split('/')[0] as string;
          if (rest2.includes('/')) {
            if (!children.has(first)) {
              // The directory's own tree oid, found by walking the tree.
              const dirTree = findTreeOid(store, repo, tree, filePath);
              children.set(first, { type: 'dir', name: first, path: `${filePath}/${first}`, sha: dirTree ?? '' });
            }
          } else {
            children.set(first, { type: 'file', name: first, path, sha: item.oid });
          }
        }
        if (children.size === 0) return jsonError(404, 'Not Found');
        return jsonResult(200, [...children.values()].sort((a, b) => (a.name < b.name ? -1 : 1)));
      }
      if (method === 'DELETE') {
        const refName = `refs/heads/${repo.defaultBranch}`;
        const tip = repo.refs.get(refName) ?? null;
        if (tip === null) return jsonError(404, 'Not Found');
        const tree = parseCommit(repo.objects.get(tip)?.data ?? Buffer.alloc(0)).tree;
        const flat = flattenTree(store.lookup(repo), tree);
        if (!flat.has(filePath)) return jsonError(404, 'Not Found');
        const message = isRecord(jsonBody) && typeof jsonBody.message === 'string' ? (jsonBody.message as string) : 'Delete file';
        const { commitSha } = store.commitFile(repo, repo.defaultBranch, filePath, null, message);
        return jsonResult(200, { commit: { sha: commitSha } });
      }
      return jsonError(404, 'Not Found');
    }

    // /repos/{o}/{r}/labels
    if (tail.length === 1 && tail[0] === 'labels') {
      if (method === 'GET') {
        return jsonResult(200, [...repo.labels.values()]);
      }
      if (method === 'POST') {
        if (!isRecord(jsonBody) || typeof jsonBody.name !== 'string' || jsonBody.name === '') {
          return jsonError(422, 'name is required');
        }
        const name = jsonBody.name as string;
        const color = typeof jsonBody.color === 'string' ? (jsonBody.color as string) : 'ededed';
        const existing = repo.labels.get(name);
        if (existing !== undefined) return jsonResult(201, existing);
        const label = { name, color };
        repo.labels.set(name, label);
        return jsonResult(201, label);
      }
      return jsonError(404, 'Not Found');
    }

    // /repos/{o}/{r}/issues...
    if (tail[0] === 'issues') {
      if (tail.length === 1) {
        if (method === 'POST') {
          if (!isRecord(jsonBody) || typeof jsonBody.title !== 'string') return jsonError(422, 'title is required');
          const labels = Array.isArray(jsonBody.labels) ? (jsonBody.labels as unknown[]) : [];
          for (const label of labels) {
            if (typeof label === 'string' && !repo.labels.has(label)) {
              return jsonError(422, `Label does not exist: ${label}`);
            }
            if (isRecord(label) && typeof label.name === 'string' && !repo.labels.has(label.name)) {
              return jsonError(422, `Label does not exist: ${label.name}`);
            }
          }
          repo.issueSeq += 1;
          const stamp = store.stamp();
          const issue: Issue = {
            id: store.nextId(),
            number: repo.issueSeq,
            title: jsonBody.title as string,
            body: typeof jsonBody.body === 'string' ? (jsonBody.body as string) : '',
            state: 'open',
            labels: labels.map((label) => (typeof label === 'string' ? label : (label as Record<string, unknown>).name as string)),
            comments: [],
            createdAt: stamp,
            updatedAt: stamp,
            seq: repo.issueSeq,
          };
          repo.issues.set(issue.number, issue);
          return jsonResult(201, issueJson(repo, issue));
        }
        if (method === 'GET') {
          const state = query.get('state') ?? 'open';
          const sort = query.get('sort') ?? 'created';
          const direction = query.get('direction') ?? 'desc';
          let issues = [...repo.issues.values()];
          if (state !== 'all') issues = issues.filter((issue) => issue.state === state);
          if (sort === 'created') {
            issues.sort((a, b) => (direction === 'asc' ? a.seq - b.seq : b.seq - a.seq));
          }
          const { page, perPage } = parsePagination(query);
          const { items, hasNext } = pageOf(issues, page, perPage);
          const headers: Record<string, string> = {};
          const link = linkHeader(baseUrl, pathname, query, page, perPage, hasNext);
          if (link !== null) headers.link = link;
          return jsonResult(200, items.map((issue) => issueJson(repo, issue)), headers);
        }
        return jsonError(404, 'Not Found');
      }
      const number = Number(tail[1]);
      if (!Number.isInteger(number) || number < 1) return jsonError(404, 'Not Found');
      const issue = repo.issues.get(number);
      if (tail.length === 2) {
        if (method === 'GET') {
          if (issue === undefined) return jsonError(404, 'Not Found');
          return jsonResult(200, issueJson(repo, issue));
        }
        if (method === 'PATCH') {
          if (issue === undefined) return jsonError(404, 'Not Found');
          if (isRecord(jsonBody)) {
            if (typeof jsonBody.state === 'string' && (jsonBody.state === 'open' || jsonBody.state === 'closed')) {
              issue.state = jsonBody.state;
            }
            if (typeof jsonBody.title === 'string') issue.title = jsonBody.title as string;
            if (typeof jsonBody.body === 'string') issue.body = jsonBody.body as string;
            if (Array.isArray(jsonBody.labels)) {
              issue.labels = (jsonBody.labels as unknown[]).map((label) => (typeof label === 'string' ? label : (label as Record<string, unknown>).name as string));
            }
          }
          issue.updatedAt = store.stamp();
          return jsonResult(200, issueJson(repo, issue));
        }
        return jsonError(404, 'Not Found');
      }
      if (tail.length === 3 && tail[2] === 'comments') {
        if (issue === undefined) return jsonError(404, 'Not Found');
        if (method === 'GET') {
          return jsonResult(
            200,
            issue.comments.map((comment) => ({
              id: comment.id,
              body: comment.body,
              user: { login: VIEWER.login, id: VIEWER.id, type: 'User' },
              created_at: comment.createdAt,
              updated_at: comment.createdAt,
            })),
          );
        }
        if (method === 'POST') {
          if (!isRecord(jsonBody) || typeof jsonBody.body !== 'string') return jsonError(422, 'body is required');
          repo.commentSeq += 1;
          const comment = { id: store.nextId(), body: jsonBody.body as string, createdAt: store.stamp() };
          issue.comments.push(comment);
          issue.updatedAt = store.stamp();
          return jsonResult(201, {
            id: comment.id,
            body: comment.body,
            user: { login: VIEWER.login, id: VIEWER.id, type: 'User' },
            created_at: comment.createdAt,
            updated_at: comment.createdAt,
          });
        }
        return jsonError(404, 'Not Found');
      }
      return jsonError(404, 'Not Found');
    }

    // /repos/{o}/{r}/pulls...
    if (tail[0] === 'pulls') {
      if (tail.length === 1) {
        if (method === 'POST') {
          if (!isRecord(jsonBody) || typeof jsonBody.head !== 'string' || typeof jsonBody.base !== 'string') {
            return jsonError(422, 'head and base are required');
          }
          const headRef = jsonBody.head as string;
          const baseRef = jsonBody.base as string;
          const headSha = repo.refs.get(`refs/heads/${headRef}`);
          const baseSha = repo.refs.get(`refs/heads/${baseRef}`);
          if (headSha === undefined || baseSha === undefined) return jsonError(422, 'head or base branch does not exist');
          repo.pullSeq += 1;
          const stamp = store.stamp();
          const pull: PullRequest = {
            id: store.nextId(),
            number: repo.pullSeq,
            title: typeof jsonBody.title === 'string' ? (jsonBody.title as string) : '',
            body: typeof jsonBody.body === 'string' ? (jsonBody.body as string) : '',
            state: 'open',
            headRef,
            headSha,
            baseRef,
            baseSha,
            merged: false,
            mergedAt: null,
            mergeCommitSha: null,
            createdAt: stamp,
            updatedAt: stamp,
            seq: repo.pullSeq,
          };
          repo.pulls.set(pull.number, pull);
          return jsonResult(201, pullJson(repo, pull));
        }
        if (method === 'GET') {
          const state = query.get('state') ?? 'open';
          let pulls = [...repo.pulls.values()];
          if (state !== 'all') pulls = pulls.filter((pull) => pull.state === state);
          pulls.sort((a, b) => b.seq - a.seq);
          const { page, perPage } = parsePagination(query);
          const { items, hasNext } = pageOf(pulls, page, perPage);
          const headers: Record<string, string> = {};
          const link = linkHeader(baseUrl, pathname, query, page, perPage, hasNext);
          if (link !== null) headers.link = link;
          return jsonResult(200, items.map((pull) => pullJson(repo, pull)), headers);
        }
        return jsonError(404, 'Not Found');
      }
      const number = Number(tail[1]);
      if (!Number.isInteger(number) || number < 1) return jsonError(404, 'Not Found');
      const pull = repo.pulls.get(number);
      if (tail.length === 2) {
        if (method === 'GET') {
          if (pull === undefined) return jsonError(404, 'Not Found');
          return jsonResult(200, pullJson(repo, pull));
        }
        return jsonError(404, 'Not Found');
      }
      if (tail.length === 3 && tail[2] === 'files' && method === 'GET') {
        if (pull === undefined) return jsonError(404, 'Not Found');
        const files = store.pullFiles(repo, pull);
        return jsonResult(
          200,
          files.map((file) => ({
            filename: file.path,
            status: file.status === 'removed' ? 'removed' : file.status,
            additions: file.additions,
            deletions: file.deletions,
            changes: file.additions + file.deletions,
            sha: file.newOid ?? file.oldOid ?? '',
          })),
        );
      }
      if (tail.length === 3 && tail[2] === 'merge' && method === 'PUT') {
        if (pull === undefined) return jsonError(404, 'Not Found');
        if (pull.state !== 'open') return jsonError(405, 'Pull request is already closed');
        const merged = store.mergePull(repo, pull);
        if (merged === null) return jsonError(405, 'Merge conflict');
        pull.merged = true;
        pull.state = 'closed';
        pull.mergedAt = store.stamp();
        pull.mergeCommitSha = merged.sha;
        pull.updatedAt = store.stamp();
        return jsonResult(200, { sha: merged.sha, merged: true, message: 'Pull request successfully merged' });
      }
      return jsonError(404, 'Not Found');
    }
  }

  return jsonError(404, 'Not Found');
}

/** The tree oid of a directory path inside a tree, or null. */
function findTreeOid(store: Store, repo: Repo, treeOid: string, dirPath: string): string | null {
  const segments = dirPath.split('/');
  let current = treeOid;
  for (const segment of segments) {
    const object = repo.objects.get(current);
    if (object === undefined || object.type !== 'tree') return null;
    const entry = parseTree(object.data).find((candidate) => candidate.name === segment && candidate.mode === '40000');
    if (entry === undefined) return null;
    current = entry.oid;
  }
  return current;
}

export { hashObject };
