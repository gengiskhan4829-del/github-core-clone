// The forge's store: git objects, refs, and the REST resources that live on top of them.
//
// Everything is in memory: the trial's pod gives one process, and the suite is its only client.
// No wall clock is read anywhere: timestamps come from a deterministic counter seeded at the
// scenario's epoch, so two runs of the same trial leave the same bytes.

import { createHash } from 'node:crypto';
import { VIEWER, viewerIdentity } from './scenario.ts';

export type GitObjectType = 'blob' | 'tree' | 'commit' | 'tag';

export interface GitObject {
  type: GitObjectType;
  data: Buffer;
}

export type ObjectLookup = (oid: string) => GitObject | undefined;

/** sha1("<type> <len>\0<data>") — the object id, exactly as git computes it. */
export function hashObject(type: GitObjectType, data: Uint8Array): string {
  const header = Buffer.from(`${type} ${data.length}\0`, 'ascii');
  return createHash('sha1').update(header).update(data).digest('hex');
}

export function putObject(objects: Map<string, GitObject>, type: GitObjectType, data: Buffer): string {
  const oid = hashObject(type, data);
  if (!objects.has(oid)) objects.set(oid, { type, data });
  return oid;
}

export interface TreeEntry {
  mode: string;
  name: string;
  oid: string;
}

/** Parse a tree object: `<mode> <name>\0<20-byte oid>` entries in order. */
export function parseTree(data: Uint8Array): TreeEntry[] {
  const entries: TreeEntry[] = [];
  let offset = 0;
  while (offset < data.length) {
    const space = data.indexOf(0x20, offset);
    const nul = data.indexOf(0x00, space + 1);
    if (space < 0 || nul < 0 || nul + 21 > data.length) break;
    const mode = Buffer.from(data.subarray(offset, space)).toString('ascii');
    const name = Buffer.from(data.subarray(space + 1, nul)).toString('utf8');
    const oid = Buffer.from(data.subarray(nul + 1, nul + 21)).toString('hex');
    entries.push({ mode, name, oid });
    offset = nul + 21;
  }
  return entries;
}

/** Build a tree object. Entries sort git-canonical: directories compare as name + '/'. */
export function buildTree(entries: readonly TreeEntry[]): Buffer {
  const sorted = [...entries].sort((a, b) => {
    const an = a.mode === '40000' ? `${a.name}/` : a.name;
    const bn = b.mode === '40000' ? `${b.name}/` : b.name;
    return an < bn ? -1 : an > bn ? 1 : 0;
  });
  const parts: Buffer[] = [];
  for (const entry of sorted) {
    parts.push(Buffer.from(`${entry.mode} ${entry.name}\0`, 'utf8'));
    parts.push(Buffer.from(entry.oid, 'hex'));
  }
  return Buffer.concat(parts);
}

export interface CommitView {
  tree: string;
  parents: string[];
  author: string;
  committer: string;
  message: string;
}

export function parseCommit(data: Uint8Array): CommitView {
  const text = Buffer.from(data).toString('utf8');
  const split = text.indexOf('\n\n');
  const header = split < 0 ? text : text.slice(0, split);
  const message = split < 0 ? '' : text.slice(split + 2);
  let tree = '';
  const parents: string[] = [];
  let author = '';
  let committer = '';
  for (const line of header.split('\n')) {
    if (line.startsWith('tree ')) tree = line.slice(5).trim();
    else if (line.startsWith('parent ')) parents.push(line.slice(7).trim());
    else if (line.startsWith('author ')) author = line.slice(7);
    else if (line.startsWith('committer ')) committer = line.slice(10);
  }
  return { tree, parents, author, committer, message };
}

export function buildCommit(fields: {
  tree: string;
  parents: readonly string[];
  author: string;
  committer: string;
  message: string;
}): Buffer {
  const lines: string[] = [`tree ${fields.tree}`];
  for (const parent of fields.parents) lines.push(`parent ${parent}`);
  lines.push(`author ${fields.author}`);
  lines.push(`committer ${fields.committer}`);
  const message = fields.message.endsWith('\n') ? fields.message : `${fields.message}\n`;
  return Buffer.from(`${lines.join('\n')}\n\n${message}`, 'utf8');
}

export interface TagView {
  object: string;
  type: string;
  tag: string;
  tagger: string;
  message: string;
}

export function parseTag(data: Uint8Array): TagView {
  const text = Buffer.from(data).toString('utf8');
  const split = text.indexOf('\n\n');
  const header = split < 0 ? text : text.slice(0, split);
  const message = split < 0 ? '' : text.slice(split + 2);
  let object = '';
  let type = '';
  let tag = '';
  let tagger = '';
  for (const line of header.split('\n')) {
    if (line.startsWith('object ')) object = line.slice(7).trim();
    else if (line.startsWith('type ')) type = line.slice(5).trim();
    else if (line.startsWith('tag ')) tag = line.slice(4).trim();
    else if (line.startsWith('tagger ')) tagger = line.slice(7);
  }
  return { object, type, tag, tagger, message };
}

/** Every object reachable from `tips`, walking commits, tags and trees. Throws on a missing object. */
export function collectReachable(tips: Iterable<string>, lookup: ObjectLookup): Set<string> {
  const seen = new Set<string>();
  const stack = [...tips];
  while (stack.length > 0) {
    const oid = stack.pop() as string;
    if (seen.has(oid)) continue;
    const object = lookup(oid);
    if (object === undefined) throw new Error(`missing object ${oid}`);
    seen.add(oid);
    if (object.type === 'commit') {
      const commit = parseCommit(object.data);
      stack.push(commit.tree);
      for (const parent of commit.parents) stack.push(parent);
    } else if (object.type === 'tag') {
      stack.push(parseTag(object.data).object);
    } else if (object.type === 'tree') {
      for (const entry of parseTree(object.data)) stack.push(entry.oid);
    }
  }
  return seen;
}

/** Is `ancestor` reachable from `tip` (or equal to it)? Missing objects answer false. */
export function isAncestor(lookup: ObjectLookup, ancestor: string, tip: string): boolean {
  if (ancestor === tip) return true;
  try {
    return collectReachable([tip], lookup).has(ancestor);
  } catch {
    return false;
  }
}

/** The nearest common ancestor of two commits, or null. */
export function mergeBase(lookup: ObjectLookup, a: string, b: string): string | null {
  const ancestorsA = new Set<string>();
  const queueA = [a];
  while (queueA.length > 0) {
    const oid = queueA.pop() as string;
    if (ancestorsA.has(oid)) continue;
    const object = lookup(oid);
    if (object === undefined || object.type !== 'commit') continue;
    ancestorsA.add(oid);
    for (const parent of parseCommit(object.data).parents) queueA.push(parent);
  }
  const queueB = [b];
  const seenB = new Set<string>();
  while (queueB.length > 0) {
    const oid = queueB.pop() as string;
    if (seenB.has(oid)) continue;
    seenB.add(oid);
    if (ancestorsA.has(oid)) return oid;
    const object = lookup(oid);
    if (object === undefined || object.type !== 'commit') continue;
    for (const parent of parseCommit(object.data).parents) queueB.push(parent);
  }
  return null;
}

/** Flatten a tree to path -> {oid, mode}, walking nested trees. */
export function flattenTree(lookup: ObjectLookup, treeOid: string, prefix = ''): Map<string, { oid: string; mode: string }> {
  const out = new Map<string, { oid: string; mode: string }>();
  const walk = (oid: string, path: string): void => {
    const object = lookup(oid);
    if (object === undefined || object.type !== 'tree') return;
    for (const entry of parseTree(object.data)) {
      const full = path === '' ? entry.name : `${path}/${entry.name}`;
      if (entry.mode === '40000') walk(entry.oid, full);
      else out.set(full, { oid: entry.oid, mode: entry.mode });
    }
  };
  walk(treeOid, prefix);
  return out;
}

export interface FileChange {
  path: string;
  status: 'added' | 'modified' | 'removed';
  oldOid: string | null;
  newOid: string | null;
  additions: number;
  deletions: number;
}

/** Count added/removed lines between two texts (a plain line diff, good enough for the suite's blobs). */
export function lineDiff(oldText: string, newText: string): { additions: number; deletions: number } {
  const oldLines = oldText === '' ? [] : oldText.split('\n');
  const newLines = newText === '' ? [] : newText.split('\n');
  const oldSet = new Map<string, number>();
  for (const line of oldLines) oldSet.set(line, (oldSet.get(line) ?? 0) + 1);
  let additions = 0;
  for (const line of newLines) {
    const count = oldSet.get(line) ?? 0;
    if (count > 0) oldSet.set(line, count - 1);
    else additions += 1;
  }
  let deletions = 0;
  for (const count of oldSet.values()) deletions += count;
  return { additions, deletions };
}

/** The file-level diff between two trees. */
export function diffTrees(lookup: ObjectLookup, baseTree: string | null, headTree: string | null): FileChange[] {
  const base = baseTree === null ? new Map() : flattenTree(lookup, baseTree);
  const head = headTree === null ? new Map() : flattenTree(lookup, headTree);
  const paths = new Set([...base.keys(), ...head.keys()]);
  const changes: FileChange[] = [];
  for (const path of [...paths].sort()) {
    const b = base.get(path);
    const h = head.get(path);
    if (b !== undefined && h !== undefined) {
      if (b.oid === h.oid) continue;
      const oldText = lookup(b.oid)?.data.toString('utf8') ?? '';
      const newText = lookup(h.oid)?.data.toString('utf8') ?? '';
      const { additions, deletions } = lineDiff(oldText, newText);
      changes.push({ path, status: 'modified', oldOid: b.oid, newOid: h.oid, additions, deletions });
    } else if (b !== undefined) {
      const oldText = lookup(b.oid)?.data.toString('utf8') ?? '';
      const { deletions } = lineDiff(oldText, '');
      changes.push({ path, status: 'removed', oldOid: b.oid, newOid: null, additions: 0, deletions });
    } else if (h !== undefined) {
      const newText = lookup(h.oid)?.data.toString('utf8') ?? '';
      const { additions } = lineDiff('', newText);
      changes.push({ path, status: 'added', oldOid: null, newOid: h.oid, additions, deletions: 0 });
    }
  }
  return changes;
}

/** Build (and store) the tree for `files`, a flat path -> blob bytes map. */
export function buildTreeForFiles(objects: Map<string, GitObject>, files: ReadonlyMap<string, Buffer>): string {
  interface Node {
    files: Map<string, Buffer>;
    dirs: Map<string, Node>;
  }
  const make = (): Node => ({ files: new Map(), dirs: new Map() });
  const root = make();
  for (const [path, data] of [...files.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) {
    const segments = path.split('/');
    let node = root;
    for (let i = 0; i < segments.length - 1; i += 1) {
      const name = segments[i] as string;
      if (!node.dirs.has(name)) node.dirs.set(name, make());
      node = node.dirs.get(name) as Node;
    }
    node.files.set(segments[segments.length - 1] as string, data);
  }
  const build = (node: Node): string => {
    const entries: TreeEntry[] = [];
    for (const [name, data] of node.files) entries.push({ mode: '100644', name, oid: putObject(objects, 'blob', data) });
    for (const [name, child] of node.dirs) entries.push({ mode: '40000', name, oid: build(child) });
    return putObject(objects, 'tree', buildTree(entries));
  };
  return build(root);
}

/** Replace one path in a tree with new blob bytes (or delete it), storing the new tree chain. */
export function updateTreePath(
  objects: Map<string, GitObject>,
  lookup: ObjectLookup,
  treeOid: string | null,
  path: string,
  data: Buffer | null,
): string {
  const files = treeOid === null ? new Map<string, Buffer>() : flattenTreeToBytes(lookup, treeOid);
  if (data === null) files.delete(path);
  else files.set(path, data);
  return buildTreeForFiles(objects, files);
}

/** A tree flattened to path -> blob bytes. */
export function flattenTreeToBytes(lookup: ObjectLookup, treeOid: string): Map<string, Buffer> {
  const out = new Map<string, Buffer>();
  for (const [path, entry] of flattenTree(lookup, treeOid)) {
    const object = lookup(entry.oid);
    if (object !== undefined) out.set(path, Buffer.from(object.data));
  }
  return out;
}

// ---------------------------------------------------------------------------
// The REST resources
// ---------------------------------------------------------------------------

/** The scenario's day one: every timestamp the forge stamps starts here and ticks up. */
export const EPOCH_SEC = 1_735_689_600;

export interface IssueComment {
  id: number;
  body: string;
  createdAt: string;
}

export interface Issue {
  id: number;
  number: number;
  title: string;
  body: string;
  state: 'open' | 'closed';
  labels: string[];
  comments: IssueComment[];
  createdAt: string;
  updatedAt: string;
  seq: number;
}

export interface PullRequest {
  id: number;
  number: number;
  title: string;
  body: string;
  state: 'open' | 'closed';
  headRef: string;
  headSha: string;
  baseRef: string;
  baseSha: string;
  merged: boolean;
  mergedAt: string | null;
  mergeCommitSha: string | null;
  createdAt: string;
  updatedAt: string;
  seq: number;
}

export interface Label {
  name: string;
  color: string;
}

export interface Repo {
  key: string;
  id: number;
  owner: string;
  name: string;
  description: string;
  private: boolean;
  defaultBranch: string;
  refs: Map<string, string>;
  objects: Map<string, GitObject>;
  issues: Map<number, Issue>;
  issueSeq: number;
  pulls: Map<number, PullRequest>;
  pullSeq: number;
  labels: Map<string, Label>;
  commentSeq: number;
  createdAt: string;
}

export function repoKey(owner: string, name: string): string {
  return `${owner}/${name}`;
}

export function b64url(text: string): string {
  return Buffer.from(text, 'utf8').toString('base64url');
}

export function repoGlobalId(repo: Repo): string {
  return b64url(`Repository:${repo.owner}/${repo.name}:${repo.id}`);
}

export function issueGlobalId(repo: Repo, issue: Issue): string {
  return b64url(`Issue:${repo.owner}/${repo.name}:${issue.number}`);
}

export function pullGlobalId(repo: Repo, pull: PullRequest): string {
  return b64url(`PullRequest:${repo.owner}/${repo.name}:${pull.number}`);
}

export function commentGlobalId(repo: Repo, issue: Issue, comment: IssueComment): string {
  return b64url(`Comment:${repo.owner}/${repo.name}:${issue.number}:${comment.id}`);
}

/** Decode a global id back to its kind and parts, or null when it is not one of ours. */
export function decodeGlobalId(id: string): { kind: string; owner: string; name: string; number: number } | null {
  try {
    const text = Buffer.from(id, 'base64url').toString('utf8');
    const match = /^(Repository|Issue|PullRequest|Comment):([^/]+)\/([^:]+)(?::(\d+))?(?::(\d+))?$/.exec(text);
    if (match === null) return null;
    return {
      kind: match[1] as string,
      owner: match[2] as string,
      name: match[3] as string,
      number: match[4] === undefined ? 0 : Number(match[4]),
    };
  } catch {
    return null;
  }
}

export class Store {
  repos = new Map<string, Repo>();
  #repoSeq = 5000;
  #globalSeq = 100000;
  #clock = 0;

  /** A deterministic timestamp: the scenario epoch plus one second per stamped event. */
  stamp(): string {
    this.#clock += 1;
    return new Date((EPOCH_SEC + this.#clock) * 1000).toISOString();
  }

  /** A deterministic git timestamp line: "Name <email> <epoch> +0000". */
  gitStamp(): { author: string; committer: string; timestamp: number } {
    this.#clock += 1;
    const timestamp = EPOCH_SEC + this.#clock;
    const identity = `${viewerIdentity()} ${timestamp} +0000`;
    return { author: identity, committer: identity, timestamp };
  }

  nextId(): number {
    this.#globalSeq += 1;
    return this.#globalSeq;
  }

  createRepo(owner: string, name: string, options: { description?: string; private?: boolean; defaultBranch?: string }): Repo | null {
    const key = repoKey(owner, name);
    if (this.repos.has(key)) return null;
    const stamp = this.stamp();
    const repo: Repo = {
      key,
      id: this.#repoSeq,
      owner,
      name,
      description: options.description ?? '',
      private: options.private ?? false,
      defaultBranch: options.defaultBranch ?? 'main',
      refs: new Map(),
      objects: new Map(),
      issues: new Map(),
      issueSeq: 0,
      pulls: new Map(),
      pullSeq: 0,
      labels: new Map(),
      commentSeq: 0,
      createdAt: stamp,
    };
    this.#repoSeq += 1;
    this.repos.set(key, repo);
    return repo;
  }

  getRepo(owner: string, name: string): Repo | undefined {
    return this.repos.get(repoKey(owner, name));
  }

  listRepos(owner: string): Repo[] {
    return [...this.repos.values()].filter((repo) => repo.owner === owner).sort((a, b) => a.id - b.id);
  }

  deleteRepo(owner: string, name: string): boolean {
    return this.repos.delete(repoKey(owner, name));
  }

  lookup(repo: Repo): ObjectLookup {
    return (oid: string) => repo.objects.get(oid);
  }

  /** Resolve a ref name, a full ref, or a commit sha (prefix allowed) to a commit oid. */
  resolveRef(repo: Repo, ref: string | undefined): string | null {
    if (ref === undefined || ref === '') {
      const tip = repo.refs.get(`refs/heads/${repo.defaultBranch}`);
      return tip ?? null;
    }
    const direct = repo.refs.get(ref) ?? repo.refs.get(`refs/heads/${ref}`) ?? repo.refs.get(`refs/tags/${ref}`);
    if (direct !== undefined) return direct;
    if (/^[0-9a-f]{4,40}$/i.test(ref)) {
      for (const oid of repo.objects.keys()) if (oid.startsWith(ref.toLowerCase())) return oid;
    }
    return null;
  }

  /** Create a commit on `branch` that sets `path` to `data` (null deletes it). */
  commitFile(repo: Repo, branch: string, path: string, data: Buffer | null, message: string): { commitSha: string; contentSha: string | null } {
    const refName = `refs/heads/${branch}`;
    const parent = repo.refs.get(refName) ?? null;
    const parentTree = parent === null ? null : parseCommit(repo.objects.get(parent)?.data ?? Buffer.alloc(0)).tree;
    const tree = updateTreePath(repo.objects, this.lookup(repo), parentTree, path, data);
    const stamp = this.gitStamp();
    const commitData = buildCommit({
      tree,
      parents: parent === null ? [] : [parent],
      author: stamp.author,
      committer: stamp.committer,
      message,
    });
    const commitSha = putObject(repo.objects, 'commit', commitData);
    repo.refs.set(refName, commitSha);
    const contentSha = data === null ? null : hashObject('blob', data);
    if (data !== null) putObject(repo.objects, 'blob', data);
    return { commitSha, contentSha };
  }

  /** The squash-merge of a pull request onto its base branch. Returns null on conflict. */
  mergePull(repo: Repo, pull: PullRequest): { sha: string } | null {
    const baseRef = `refs/heads/${pull.baseRef}`;
    const headRef = `refs/heads/${pull.headRef}`;
    const baseTip = repo.refs.get(baseRef);
    const headTip = repo.refs.get(headRef);
    if (baseTip === undefined || headTip === undefined) return null;
    const lookup = this.lookup(repo);
    const baseCommit = parseCommit(lookup(baseTip)?.data ?? Buffer.alloc(0));
    const headCommit = parseCommit(lookup(headTip)?.data ?? Buffer.alloc(0));
    const baseTree = baseCommit.tree;
    const headTree = headCommit.tree;
    const ancestor = mergeBase(lookup, baseTip, headTip);
    const ancestorTree = ancestor === null ? null : parseCommit(lookup(ancestor)?.data ?? Buffer.alloc(0)).tree;
    const headChanges = diffTrees(lookup, ancestorTree, headTree);
    const baseChanges = new Map(diffTrees(lookup, ancestorTree, baseTree).map((change) => [change.path, change]));
    // A file both sides changed to different bytes is a conflict.
    for (const change of headChanges) {
      const other = baseChanges.get(change.path);
      if (other !== undefined && other.newOid !== change.newOid) return null;
    }
    const files = flattenTreeToBytes(lookup, baseTree);
    for (const change of headChanges) {
      if (change.status === 'removed') files.delete(change.path);
      else if (change.newOid !== null) {
        const object = lookup(change.newOid);
        if (object !== undefined) files.set(change.path, Buffer.from(object.data));
      }
    }
    const tree = buildTreeForFiles(repo.objects, files);
    const stamp = this.gitStamp();
    const commitData = buildCommit({
      tree,
      parents: [baseTip],
      author: stamp.author,
      committer: stamp.committer,
      message: `Merge pull request #${pull.number} from ${pull.headRef}\n\n${pull.title}`,
    });
    const sha = putObject(repo.objects, 'commit', commitData);
    repo.refs.set(baseRef, sha);
    return { sha };
  }

  /** Is this pull request mergeable right now (no conflicting file changes)? */
  pullMergeable(repo: Repo, pull: PullRequest): 'MERGEABLE' | 'CONFLICTING' | 'UNKNOWN' {
    if (pull.state !== 'open') return 'UNKNOWN';
    const baseTip = repo.refs.get(`refs/heads/${pull.baseRef}`);
    const headTip = repo.refs.get(`refs/heads/${pull.headRef}`);
    if (baseTip === undefined || headTip === undefined) return 'UNKNOWN';
    const lookup = this.lookup(repo);
    const ancestor = mergeBase(lookup, baseTip, headTip);
    if (ancestor === null) return 'UNKNOWN';
    const ancestorTree = parseCommit(lookup(ancestor)?.data ?? Buffer.alloc(0)).tree;
    const headTree = parseCommit(lookup(headTip)?.data ?? Buffer.alloc(0)).tree;
    const baseTree = parseCommit(lookup(baseTip)?.data ?? Buffer.alloc(0)).tree;
    const headChanges = diffTrees(lookup, ancestorTree, headTree);
    const baseChanges = new Map(diffTrees(lookup, ancestorTree, baseTree).map((change) => [change.path, change]));
    for (const change of headChanges) {
      const other = baseChanges.get(change.path);
      if (other !== undefined && other.newOid !== change.newOid) return 'CONFLICTING';
    }
    return 'MERGEABLE';
  }

  /** The file changes of a pull request: merge-base tree vs head tree. */
  pullFiles(repo: Repo, pull: PullRequest): FileChange[] {
    const baseTip = repo.refs.get(`refs/heads/${pull.baseRef}`);
    const headTip = repo.refs.get(`refs/heads/${pull.headRef}`);
    if (baseTip === undefined || headTip === undefined) return [];
    const lookup = this.lookup(repo);
    const ancestor = mergeBase(lookup, baseTip, headTip);
    const ancestorTree = ancestor === null ? null : parseCommit(lookup(ancestor)?.data ?? Buffer.alloc(0)).tree;
    const headTree = parseCommit(lookup(headTip)?.data ?? Buffer.alloc(0)).tree;
    return diffTrees(lookup, ancestorTree, headTree);
  }
}
