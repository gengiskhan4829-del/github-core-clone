// The git smart-HTTP wire: pkt-lines, packfiles, upload-pack v2 and receive-pack v0.
//
// This module speaks the protocol the suite's client speaks (kit program/env/src/git-client.ts),
// with no git binary anywhere: objects are hashed and deflated with node:crypto / node:zlib only.
// Packs we send carry full objects only (no deltas); packs we receive may carry OFS_DELTA and
// REF_DELTA entries, which we resolve against the pack itself and the repository's store.

import { createHash, randomUUID } from 'node:crypto';
import { deflateSync, inflateSync } from 'node:zlib';
import {
  collectReachable,
  hashObject,
  parseCommit,
  parseTag,
  parseTree,
  type GitObject,
  type GitObjectType,
  type ObjectLookup,
  type Repo,
} from './store.ts';

export const ZERO_OID = '0'.repeat(40);

// ---------------------------------------------------------------------------
// pkt-line framing
// ---------------------------------------------------------------------------

/** One pkt-line: 4 hex length bytes (the length includes those 4) + payload. */
export function pktLine(payload: string | Buffer): Buffer {
  const data = typeof payload === 'string' ? Buffer.from(payload, 'utf8') : payload;
  const length = data.length + 4;
  const header = Buffer.from(length.toString(16).padStart(4, '0'), 'ascii');
  return Buffer.concat([header, data]);
}

export const FLUSH = Buffer.from('0000', 'ascii');
export const DELIM = Buffer.from('0001', 'ascii');

export function pktLines(lines: readonly (string | Buffer)[]): Buffer {
  return Buffer.concat(lines.map((line) => pktLine(line)));
}

export type Packet =
  | { kind: 'data'; payload: Buffer }
  | { kind: 'flush' }
  | { kind: 'delim' }
  | { kind: 'response-end' };

/** Split a byte stream into pkt-line packets. Throws on a malformed frame. */
export function decodePktLines(bytes: Buffer): Packet[] {
  const packets: Packet[] = [];
  let offset = 0;
  while (offset < bytes.length) {
    if (offset + 4 > bytes.length) throw new Error('truncated pkt-line header');
    const length = parseInt(bytes.subarray(offset, offset + 4).toString('ascii'), 16);
    if (Number.isNaN(length) || length < 0) throw new Error('bad pkt-line length');
    if (length === 0) {
      packets.push({ kind: 'flush' });
      offset += 4;
    } else if (length === 1) {
      packets.push({ kind: 'delim' });
      offset += 4;
    } else if (length === 2) {
      packets.push({ kind: 'response-end' });
      offset += 4;
    } else {
      if (offset + length > bytes.length) throw new Error('truncated pkt-line payload');
      packets.push({ kind: 'data', payload: Buffer.from(bytes.subarray(offset + 4, offset + length)) });
      offset += length;
    }
  }
  return packets;
}

/** The data lines of a pkt-line stream, as strings without the trailing newline. */
export function pktDataLines(bytes: Buffer): string[] {
  const lines: string[] = [];
  for (const packet of decodePktLines(bytes)) {
    if (packet.kind === 'data') lines.push(packet.payload.toString('utf8').replace(/\n$/, ''));
  }
  return lines;
}

// ---------------------------------------------------------------------------
// packfiles
// ---------------------------------------------------------------------------

const PACK_TYPE_CODE: Record<GitObjectType, number> = { commit: 1, tree: 2, blob: 3, tag: 4 };
const CODE_PACK_TYPE: Record<number, GitObjectType> = { 1: 'commit', 2: 'tree', 3: 'blob', 4: 'tag' };

function packObjectHeader(typeCode: number, size: number): Buffer {
  const bytes: number[] = [];
  let first = (typeCode << 4) | (size & 0x0f);
  size >>= 4;
  if (size > 0) first |= 0x80;
  bytes.push(first);
  while (size > 0) {
    let next = size & 0x7f;
    size >>= 7;
    if (size > 0) next |= 0x80;
    bytes.push(next);
  }
  return Buffer.from(bytes);
}

/** A packfile of full (undeltified) objects, with its sha1 trailer. */
export function writePack(objects: Iterable<GitObject>): Buffer {
  const list = [...objects];
  const parts: Buffer[] = [];
  const header = Buffer.alloc(12);
  header.write('PACK', 0, 4, 'ascii');
  header.writeUInt32BE(2, 4);
  header.writeUInt32BE(list.length, 8);
  parts.push(header);
  for (const object of list) {
    parts.push(packObjectHeader(PACK_TYPE_CODE[object.type], object.data.length));
    parts.push(deflateSync(object.data));
  }
  const body = Buffer.concat(parts);
  return Buffer.concat([body, createHash('sha1').update(body).digest()]);
}

interface RawPackEntry {
  offset: number;
  typeCode: number;
  size: number;
  data: Buffer;
  baseOffset?: number;
  baseOid?: string;
}

function readVarintSize(buffer: Buffer, offset: number): { size: number; first: number; next: number } {
  let byte = buffer[offset] as number;
  let size = byte & 0x0f;
  let shift = 4;
  let next = offset + 1;
  while (byte & 0x80) {
    byte = buffer[next] as number;
    size |= (byte & 0x7f) << shift;
    shift += 7;
    next += 1;
  }
  return { size, first: buffer[offset] as number, next };
}

function readOfsDeltaBase(buffer: Buffer, offset: number): { baseOffset: number; next: number } {
  let byte = buffer[offset] as number;
  let value = byte & 0x7f;
  let next = offset + 1;
  while (byte & 0x80) {
    byte = buffer[next] as number;
    value = ((value + 1) << 7) | (byte & 0x7f);
    next += 1;
  }
  return { baseOffset: value, next };
}

function inflateAt(buffer: Buffer, offset: number): { data: Buffer; next: number } {
  // inflateSync needs the exact stream; try growing windows until the stream ends cleanly.
  // zlib streams carry their own end, so inflate the remainder and find the consumed length by
  // re-inflating with a trailing-garbage-tolerant approach: use inflateSync on a slice and binary
  // search the smallest slice that inflates without error.
  let low = offset + 1;
  let high = buffer.length;
  let data: Buffer | null = null;
  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    try {
      data = inflateSync(buffer.subarray(offset, mid));
      high = mid - 1;
    } catch {
      low = mid + 1;
    }
  }
  if (data === null) throw new Error('could not inflate pack entry');
  // The smallest working slice is low; the stream ends at low.
  return { data, next: low };
}

/** Apply a git delta to a base object. */
export function applyDelta(base: Buffer, delta: Buffer): Buffer {
  let offset = 0;
  const readVarint = (): number => {
    let value = 0;
    let shift = 0;
    for (;;) {
      const byte = delta[offset] as number;
      offset += 1;
      value |= (byte & 0x7f) << shift;
      shift += 7;
      if ((byte & 0x80) === 0) break;
    }
    return value;
  };
  const baseSize = readVarint();
  const resultSize = readVarint();
  if (baseSize !== base.length) throw new Error(`delta base size ${baseSize} does not match ${base.length}`);
  const parts: Buffer[] = [];
  let total = 0;
  while (offset < delta.length) {
    const op = delta[offset] as number;
    offset += 1;
    if (op & 0x80) {
      let copyOffset = 0;
      let copySize = 0;
      for (let i = 0; i < 4; i += 1) {
        if (op & (1 << i)) {
          copyOffset |= (delta[offset] as number) << (8 * i);
          offset += 1;
        }
      }
      for (let i = 0; i < 3; i += 1) {
        if (op & (0x10 << i)) {
          copySize |= (delta[offset] as number) << (8 * i);
          offset += 1;
        }
      }
      if (copySize === 0) copySize = 0x10000;
      parts.push(base.subarray(copyOffset, copyOffset + copySize));
      total += copySize;
    } else if (op > 0) {
      parts.push(Buffer.from(delta.subarray(offset, offset + op)));
      offset += op;
      total += op;
    } else {
      throw new Error('delta opcode 0');
    }
  }
  const result = Buffer.concat(parts);
  if (result.length !== resultSize || total !== resultSize) throw new Error('delta result size mismatch');
  return result;
}

export interface PackReadResult {
  objects: Map<string, GitObject>;
  deltaCount: number;
}

/**
 * Parse a packfile (v2 or v3), resolving OFS_DELTA and REF_DELTA entries against the pack and
 * `lookup` (the repository's existing objects). Verifies the trailer checksum.
 */
export function readPack(pack: Buffer, lookup?: ObjectLookup): PackReadResult {
  if (pack.length < 32) throw new Error(`pack is ${pack.length} bytes, too short`);
  if (pack.subarray(0, 4).toString('ascii') !== 'PACK') throw new Error('pack does not start with PACK');
  const version = pack.readUInt32BE(4);
  if (version !== 2 && version !== 3) throw new Error(`unsupported pack version ${version}`);
  const declaredCount = pack.readUInt32BE(8);
  const trailerStart = pack.length - 20;
  const trailer = pack.subarray(trailerStart).toString('hex');
  const computed = createHash('sha1').update(pack.subarray(0, trailerStart)).digest('hex');
  if (trailer !== computed) throw new Error('pack trailer checksum mismatch');

  const raw: RawPackEntry[] = [];
  const byOffset = new Map<number, RawPackEntry>();
  let offset = 12;
  for (let index = 0; index < declaredCount; index += 1) {
    const entryOffset = offset;
    const header = readVarintSize(pack, offset);
    offset = header.next;
    const typeCode = (header.first >> 4) & 0x07;
    const entry: RawPackEntry = { offset: entryOffset, typeCode, size: header.size, data: Buffer.alloc(0) };
    if (typeCode === 6) {
      const base = readOfsDeltaBase(pack, offset);
      offset = base.next;
      if (base.baseOffset <= 0 || base.baseOffset > entryOffset) throw new Error(`ofs-delta at ${entryOffset} names an invalid base offset`);
      entry.baseOffset = entryOffset - base.baseOffset;
    } else if (typeCode === 7) {
      if (offset + 20 > trailerStart) throw new Error('ref-delta base id is truncated');
      entry.baseOid = pack.subarray(offset, offset + 20).toString('hex');
      offset += 20;
    } else if (CODE_PACK_TYPE[typeCode] === undefined) {
      throw new Error(`pack entry ${index} has unknown type code ${typeCode}`);
    }
    const inflated = inflateAt(pack.subarray(0, trailerStart), offset);
    if (inflated.data.length !== header.size) {
      throw new Error(`pack entry at ${entryOffset} declares ${header.size} bytes but inflated to ${inflated.data.length}`);
    }
    entry.data = inflated.data;
    offset = inflated.next;
    raw.push(entry);
    byOffset.set(entryOffset, entry);
  }

  const objects = new Map<string, GitObject>();
  let deltaCount = 0;
  const resolve = (entry: RawPackEntry, seen: Set<number>): { type: GitObjectType; data: Buffer } => {
    if (seen.has(entry.offset)) throw new Error('delta cycle in pack');
    seen.add(entry.offset);
    if (entry.typeCode === 6 || entry.typeCode === 7) {
      deltaCount += 1;
      let base: { type: GitObjectType; data: Buffer } | undefined;
      if (entry.typeCode === 6) {
        const baseEntry = byOffset.get(entry.baseOffset as number);
        if (baseEntry === undefined) throw new Error('ofs-delta base not in pack');
        base = resolve(baseEntry, seen);
      } else {
        const baseOid = entry.baseOid as string;
        const existing = lookup?.(baseOid);
        if (existing !== undefined) base = existing;
        else {
          const baseEntry = raw.find((candidate) => hashObjectOfEntry(candidate, byOffset, lookup) === baseOid);
          if (baseEntry === undefined) throw new Error(`ref-delta base ${baseOid} is not available`);
          base = resolve(baseEntry, seen);
        }
      }
      return { type: base.type, data: applyDelta(base.data, entry.data) };
    }
    return { type: CODE_PACK_TYPE[entry.typeCode] as GitObjectType, data: entry.data };
  };
  // A lazy oid helper for ref-delta lookup by oid: resolve entries once, in order, caching results.
  const resolvedByOffset = new Map<number, { type: GitObjectType; data: Buffer; oid: string }>();
  const resolveEntry = (entry: RawPackEntry): { type: GitObjectType; data: Buffer; oid: string } => {
    const cached = resolvedByOffset.get(entry.offset);
    if (cached !== undefined) return cached;
    const resolved = resolve(entry, new Set());
    const oid = hashObject(resolved.type, resolved.data);
    const result = { ...resolved, oid };
    resolvedByOffset.set(entry.offset, result);
    return result;
  };
  function hashObjectOfEntry(entry: RawPackEntry, _byOffset: Map<number, RawPackEntry>, _lookup?: ObjectLookup): string {
    return resolveEntry(entry).oid;
  }
  for (const entry of raw) {
    const resolved = resolveEntry(entry);
    objects.set(resolved.oid, { type: resolved.type, data: resolved.data });
  }
  return { objects, deltaCount };
}

// ---------------------------------------------------------------------------
// refs
// ---------------------------------------------------------------------------

export interface RefLine {
  oid: string;
  name: string;
  peeled?: string;
  symrefTarget?: string;
  unborn?: boolean;
}

/** Every ref of a repo, sorted, with peeled tag targets. */
export function listRefs(repo: Repo): RefLine[] {
  const refs: RefLine[] = [];
  const names = [...repo.refs.keys()].sort();
  for (const name of names) {
    const oid = repo.refs.get(name) as string;
    const ref: RefLine = { oid, name };
    const object = repo.objects.get(oid);
    if (object !== undefined && object.type === 'tag') {
      ref.peeled = parseTag(object.data).object;
    }
    refs.push(ref);
  }
  return refs;
}

export function defaultBranchRef(repo: Repo): string {
  return `refs/heads/${repo.defaultBranch}`;
}

/** The HEAD line for ls-refs / advertisements. */
export function headRefLine(repo: Repo): RefLine {
  const tip = repo.refs.get(defaultBranchRef(repo));
  if (tip === undefined) return { oid: ZERO_OID, name: 'HEAD', symrefTarget: defaultBranchRef(repo), unborn: true };
  return { oid: tip, name: 'HEAD', symrefTarget: defaultBranchRef(repo) };
}

// ---------------------------------------------------------------------------
// info/refs advertisements
// ---------------------------------------------------------------------------

const AGENT = 'github-core-clone/1.0';

function v0RefLines(repo: Repo, capabilities: string): Buffer {
  const refs = listRefs(repo);
  const chunks: Buffer[] = [];
  if (refs.length === 0) {
    chunks.push(pktLine(`${ZERO_OID} capabilities^{}\0${capabilities}\n`));
  } else {
    refs.forEach((ref, index) => {
      const caps = index === 0 ? `\0${capabilities}` : '';
      chunks.push(pktLine(`${ref.oid} ${ref.name}${caps}\n`));
    });
  }
  chunks.push(FLUSH);
  return Buffer.concat(chunks);
}

/** The v0 ref advertisement body for a service, with its "# service=" preamble. */
export function advertisementV0(repo: Repo, service: 'git-upload-pack' | 'git-receive-pack'): Buffer {
  const caps =
    service === 'git-upload-pack'
      ? `side-band-64k symref=HEAD:${defaultBranchRef(repo)}`
      : 'report-status side-band-64k delete-refs';
  return Buffer.concat([pktLine(`# service=${service}\n`), FLUSH, v0RefLines(repo, caps)]);
}

/** The v2 capability advertisement: "version 2" then one capability per line. */
export function advertisementV2(): Buffer {
  const lines = [
    'version 2',
    'ls-refs=unborn',
    'fetch=shallow wait-for-done',
    'object-format=sha1',
    `agent=${AGENT}`,
    'server-option',
  ];
  return Buffer.concat([...lines.map((line) => pktLine(`${line}\n`)), FLUSH]);
}

// ---------------------------------------------------------------------------
// upload-pack v2: ls-refs and fetch
// ---------------------------------------------------------------------------

export interface LsRefsArgs {
  peel: boolean;
  symrefs: boolean;
  unborn: boolean;
  prefixes: string[];
}

export interface FetchArgs {
  wants: string[];
  haves: string[];
  shallow: string[];
  depth: number | null;
  waitForDone: boolean;
}

export interface V2Request {
  command: 'ls-refs' | 'fetch' | string;
  lsRefs: LsRefsArgs;
  fetch: FetchArgs;
}

/** Parse a v2 upload-pack request body into its command and arguments. */
export function parseV2Request(body: Buffer): V2Request {
  const request: V2Request = {
    command: '',
    lsRefs: { peel: false, symrefs: false, unborn: false, prefixes: [] },
    fetch: { wants: [], haves: [], shallow: [], depth: null, waitForDone: false },
  };
  for (const packet of decodePktLines(body)) {
    if (packet.kind !== 'data') continue;
    const line = packet.payload.toString('utf8').replace(/\n$/, '');
    if (line.startsWith('command=')) request.command = line.slice('command='.length);
    else if (line === 'peel') request.lsRefs.peel = true;
    else if (line === 'symrefs') request.lsRefs.symrefs = true;
    else if (line === 'unborn') request.lsRefs.unborn = true;
    else if (line.startsWith('ref-prefix ')) request.lsRefs.prefixes.push(line.slice('ref-prefix '.length));
    else if (line.startsWith('want ')) request.fetch.wants.push(line.slice(5).trim());
    else if (line.startsWith('have ')) request.fetch.haves.push(line.slice(5).trim());
    else if (line.startsWith('shallow ')) request.fetch.shallow.push(line.slice(8).trim());
    else if (line.startsWith('deepen ')) request.fetch.depth = Number(line.slice(7).trim());
    else if (line === 'wait-for-done') request.fetch.waitForDone = true;
  }
  return request;
}

/** Answer a v2 ls-refs request. */
export function handleLsRefs(repo: Repo, args: LsRefsArgs): Buffer {
  const lines: string[] = [];
  const head = headRefLine(repo);
  const refs = listRefs(repo);
  const keep = (name: string): boolean => args.prefixes.length === 0 || args.prefixes.some((prefix) => name.startsWith(prefix));
  if (head.unborn === true) {
    if (args.unborn) lines.push(`unborn HEAD symref-target:${head.symrefTarget}`);
  } else if (keep('HEAD')) {
    lines.push(`${head.oid} HEAD${args.symrefs ? ` symref-target:${head.symrefTarget}` : ''}`);
  }
  for (const ref of refs) {
    if (!keep(ref.name)) continue;
    let line = `${ref.oid} ${ref.name}`;
    if (args.peel && ref.peeled !== undefined) line += ` peeled:${ref.peeled}`;
    lines.push(line);
  }
  return Buffer.concat([...lines.map((line) => pktLine(`${line}\n`)), FLUSH]);
}

interface FetchPlan {
  toSend: GitObject[];
  shallow: string[];
  unshallow: string[];
  /** Haves that are ancestors of the wants — the common commits to ACK. */
  common: string[];
}

/**
 * Work out what a fetch sends: the objects reachable from the wants that the client does not
 * already hold (its haves, stopping at its shallow boundaries), honoring `deepen`.
 */
export function planFetch(repo: Repo, args: FetchArgs): FetchPlan {
  const lookup: ObjectLookup = (oid) => repo.objects.get(oid);
  const shallowBoundaries = new Set(args.shallow);

  // What the client already holds: reachable from its haves, without descending past a shallow
  // boundary commit (it holds the boundary commit itself, but not its parents).
  const held = new Set<string>();
  const stack: Array<{ oid: string; stop: boolean }> = args.haves.map((oid) => ({ oid, stop: false }));
  while (stack.length > 0) {
    const { oid, stop } = stack.pop() as { oid: string; stop: boolean };
    if (held.has(oid)) continue;
    const object = lookup(oid);
    if (object === undefined) continue;
    held.add(oid);
    if (stop) continue;
    if (object.type === 'commit') {
      const commit = parseCommit(object.data);
      if (!shallowBoundaries.has(oid)) {
        stack.push({ oid: commit.tree, stop: false });
        for (const parent of commit.parents) stack.push({ oid: parent, stop: false });
      } else {
        stack.push({ oid: commit.tree, stop: false });
      }
    } else if (object.type === 'tag') {
      stack.push({ oid: parseTag(object.data).object, stop: false });
    } else if (object.type === 'tree') {
      for (const entry of parseTree(object.data)) stack.push({ oid: entry.oid, stop: false });
    }
  }

  let wanted = new Set<string>();
  let shallow: string[] = [];
  let unshallow: string[] = [];
  if (args.depth !== null && Number.isFinite(args.depth) && args.depth > 0) {
    const depth = Math.trunc(args.depth);
    // Generations of commits: gen 0 is the want tips; gen depth-1 is the new boundary.
    const included = new Set<string>();
    let frontier = [...new Set(args.wants)];
    const boundary: string[] = [];
    for (let gen = 0; gen < depth; gen += 1) {
      const next: string[] = [];
      for (const oid of frontier) {
        if (included.has(oid)) continue;
        const object = lookup(oid);
        if (object === undefined || object.type !== 'commit') continue;
        included.add(oid);
        if (gen === depth - 1) boundary.push(oid);
        for (const parent of parseCommit(object.data).parents) next.push(parent);
      }
      frontier = next;
    }
    shallow = boundary;
    unshallow = [...shallowBoundaries].filter((oid) => included.has(oid));
    // Depth-limited: only the included generations plus their trees/blobs. The full reachable
    // closure would smuggle the parents in and break shallow clones (the tip's tree is included,
    // its parent commit is not).
    wanted = collectShallowWanted(included, lookup);
  } else {
    wanted = collectReachableSafe(new Set(args.wants), lookup);
  }

  const toSend: GitObject[] = [];
  for (const oid of wanted) {
    if (held.has(oid)) continue;
    const object = lookup(oid);
    if (object !== undefined) toSend.push(object);
  }
  // The common commits: haves that are ancestors of a want (full history, depth aside — a have
  // is common even when the depth limit keeps it out of the pack).
  const fullWanted = collectReachableSafe(new Set(args.wants), lookup);
  const common = args.haves.filter((oid) => fullWanted.has(oid));
  // Deterministic pack order: commits first (parents after children is not required), then trees,
  // then blobs, each by oid — a stable order keeps replays identical.
  const order: Record<GitObjectType, number> = { commit: 0, tag: 1, tree: 2, blob: 3 };
  toSend.sort((a, b) => {
    const byType = order[a.type] - order[b.type];
    if (byType !== 0) return byType;
    return hashObject(a.type, a.data) < hashObject(b.type, b.data) ? -1 : 1;
  });
  return { toSend, shallow, unshallow, common };
}

/**
 * The objects a depth-limited fetch may send: the given commits themselves plus each commit's
 * tree closure (trees and blobs), but never a parent commit. Used for `deepen` fetches.
 */
function collectShallowWanted(included: Set<string>, lookup: ObjectLookup): Set<string> {
  const out = new Set<string>();
  const stack: string[] = [...included];
  while (stack.length > 0) {
    const oid = stack.pop() as string;
    if (out.has(oid)) continue;
    const object = lookup(oid);
    if (object === undefined) continue;
    out.add(oid);
    if (object.type === 'commit') {
      stack.push(parseCommit(object.data).tree);
    } else if (object.type === 'tag') {
      stack.push(parseTag(object.data).object);
    } else if (object.type === 'tree') {
      for (const entry of parseTree(object.data)) stack.push(entry.oid);
    }
  }
  return out;
}

function collectReachableSafe(tips: Set<string>, lookup: ObjectLookup): Set<string> {
  try {
    return collectReachable(tips, lookup);
  } catch {
    // A want the server cannot resolve contributes nothing.
    const out = new Set<string>();
    for (const tip of tips) {
      try {
        for (const oid of collectReachable([tip], lookup)) out.add(oid);
      } catch {
        // skip an unresolvable want
      }
    }
    return out;
  }
}

/** Answer a v2 fetch request: acknowledgments, shallow-info, and a sideband packfile section. */
export function handleFetch(repo: Repo, args: FetchArgs): Buffer {
  const plan = planFetch(repo, args);
  const chunks: Buffer[] = [];
  // Protocol v2: the acknowledgments section is only present when the client
  // negotiated (sent "have" lines) or asked for "wait-for-done". A plain clone
  // sends neither, and a real git client then expects the packfile section
  // first — sending acknowledgments unconditionally makes it abort with
  // "expected 'packfile', received 'acknowledgments'".
  const negotiated = args.haves.length > 0 || args.waitForDone;
  if (negotiated) {
    chunks.push(pktLine('acknowledgments\n'));
    // ACK every common commit, then "ready" so the client stops negotiating and reads the pack.
    // A bare NAK with no "ready" makes a real git client abort with
    // "expected no other sections to be sent after no 'ready'".
    if (plan.common.length > 0) {
      for (const oid of plan.common) chunks.push(pktLine(`ACK ${oid}\n`));
    } else {
      chunks.push(pktLine('NAK\n'));
    }
    chunks.push(pktLine('ready\n'));
    chunks.push(DELIM);
  }
  if (plan.shallow.length > 0 || plan.unshallow.length > 0) {
    chunks.push(pktLine('shallow-info\n'));
    for (const oid of plan.shallow) chunks.push(pktLine(`shallow ${oid}\n`));
    for (const oid of plan.unshallow) chunks.push(pktLine(`unshallow ${oid}\n`));
    chunks.push(DELIM);
  }
  if (plan.toSend.length > 0) {
    chunks.push(pktLine('packfile\n'));
    const pack = writePack(plan.toSend);
    // Sideband band 1, chunked so no pkt-line exceeds the 64 KiB frame.
    const MAX_DATA = 65515;
    for (let offset = 0; offset < pack.length; offset += MAX_DATA) {
      const slice = pack.subarray(offset, Math.min(pack.length, offset + MAX_DATA));
      const framed = Buffer.concat([Buffer.from([1]), Buffer.from(slice)]);
      chunks.push(pktLine(framed));
    }
  }
  chunks.push(FLUSH);
  return Buffer.concat(chunks);
}

// ---------------------------------------------------------------------------
// receive-pack v0: push
// ---------------------------------------------------------------------------

export interface PushCommand {
  oldOid: string;
  newOid: string;
  ref: string;
}

export interface PushReportLine {
  ref: string;
  ok: boolean;
  reason: string;
}

/**
 * Parse a receive-pack request body: pkt-line commands up to the flush, then raw pack bytes.
 * The first command line may carry "\0<capabilities>".
 */
export function parsePush(body: Buffer): { commands: PushCommand[]; pack: Buffer | null } {
  const commands: PushCommand[] = [];
  let offset = 0;
  let pack: Buffer | null = null;
  while (offset < body.length) {
    if (offset + 4 > body.length) break;
    const length = parseInt(body.subarray(offset, offset + 4).toString('ascii'), 16);
    if (Number.isNaN(length)) break;
    if (length === 0) {
      offset += 4;
      pack = body.subarray(offset);
      break;
    }
    if (length < 4 || offset + length > body.length) break;
    const line = body.subarray(offset + 4, offset + length).toString('utf8');
    const nul = line.indexOf('\0');
    const command = (nul >= 0 ? line.slice(0, nul) : line).replace(/\n$/, '');
    const parts = command.split(' ');
    if (parts.length >= 3) {
      commands.push({ oldOid: parts[0] as string, newOid: parts[1] as string, ref: parts.slice(2).join(' ') });
    }
    offset += length;
  }
  return { commands, pack: pack !== null && pack.length > 0 ? Buffer.from(pack) : null };
}

/**
 * Apply a push to a repository: store the pack's objects, then apply each command, refusing
 * non-fast-forwards per ref while still applying the fast-forward ones.
 */
export function applyPush(repo: Repo, body: Buffer): { unpackOk: boolean; unpackDetail: string; refs: PushReportLine[] } {
  const { commands, pack } = parsePush(body);
  const lookup: ObjectLookup = (oid) => repo.objects.get(oid);
  let unpackOk = true;
  let unpackDetail = 'ok';
  let newObjects = new Map<string, GitObject>();
  if (pack !== null) {
    try {
      const read = readPack(pack, lookup);
      newObjects = read.objects;
    } catch (err) {
      unpackOk = false;
      unpackDetail = err instanceof Error ? err.message : 'unpack error';
    }
  }
  const results: PushReportLine[] = [];
  if (!unpackOk) {
    for (const command of commands) results.push({ ref: command.ref, ok: false, reason: 'unpack error' });
    return { unpackOk, unpackDetail, refs: results };
  }
  // Store the new objects first, so closure checks see them.
  for (const [oid, object] of newObjects) {
    if (!repo.objects.has(oid)) repo.objects.set(oid, object);
  }
  for (const command of commands) {
    const current = repo.refs.get(command.ref);
    if (command.newOid === ZERO_OID) {
      // Delete.
      if (current === undefined) {
        results.push({ ref: command.ref, ok: false, reason: 'ref does not exist' });
      } else if (command.oldOid !== ZERO_OID && command.oldOid !== current) {
        results.push({ ref: command.ref, ok: false, reason: 'invalid old value' });
      } else {
        repo.refs.delete(command.ref);
        results.push({ ref: command.ref, ok: true, reason: '' });
      }
      continue;
    }
    const target = repo.objects.get(command.newOid);
    if (target === undefined || (target.type !== 'commit' && target.type !== 'tag')) {
      results.push({ ref: command.ref, ok: false, reason: 'object not found' });
      continue;
    }
    // The new tip's history must close over objects the server holds.
    try {
      collectReachable([command.newOid], lookup);
    } catch {
      results.push({ ref: command.ref, ok: false, reason: 'object not found' });
      continue;
    }
    if (current === undefined) {
      if (command.oldOid !== ZERO_OID) {
        results.push({ ref: command.ref, ok: false, reason: 'invalid old value' });
        continue;
      }
      repo.refs.set(command.ref, command.newOid);
      results.push({ ref: command.ref, ok: true, reason: '' });
      continue;
    }
    if (command.oldOid !== ZERO_OID && command.oldOid !== current) {
      results.push({ ref: command.ref, ok: false, reason: 'invalid old value' });
      continue;
    }
    if (!isAncestorFastForward(lookup, current, command.newOid)) {
      results.push({ ref: command.ref, ok: false, reason: 'non-fast-forward' });
      continue;
    }
    repo.refs.set(command.ref, command.newOid);
    results.push({ ref: command.ref, ok: true, reason: '' });
  }
  return { unpackOk, unpackDetail, refs: results };
}

function isAncestorFastForward(lookup: ObjectLookup, ancestor: string, tip: string): boolean {
  if (ancestor === tip) return true;
  // Walk the tip's commit ancestry looking for the ancestor.
  const seen = new Set<string>();
  const queue = [tip];
  while (queue.length > 0) {
    const oid = queue.pop() as string;
    if (seen.has(oid)) continue;
    seen.add(oid);
    if (oid === ancestor) return true;
    const object = lookup(oid);
    if (object === undefined) continue;
    if (object.type === 'commit') {
      for (const parent of parseCommit(object.data).parents) queue.push(parent);
    } else if (object.type === 'tag') {
      queue.push(parseTag(object.data).object);
    }
  }
  return false;
}

/** The report-status stream, sideband-framed in band 1, then a flush. */
export function pushReportResponse(result: { unpackOk: boolean; unpackDetail: string; refs: PushReportLine[] }): Buffer {
  const lines: string[] = [`unpack ${result.unpackOk ? 'ok' : result.unpackDetail}`];
  for (const ref of result.refs) {
    lines.push(ref.ok ? `ok ${ref.ref}` : `ng ${ref.ref} ${ref.reason}`);
  }
  // The report stream itself ends with a flush packet INSIDE band 1 (real git's receive-pack
  // emits it); without it a real git client reads the status lines and then dies with
  // "the remote end hung up unexpectedly". The outer flush ends the response after that.
  const inner = Buffer.concat([
    Buffer.concat(lines.map((line) => pktLine(`${line}\n`))),
    FLUSH,
  ]);
  const chunks: Buffer[] = [];
  const MAX_DATA = 65515;
  for (let offset = 0; offset < inner.length; offset += MAX_DATA) {
    const slice = inner.subarray(offset, Math.min(inner.length, offset + MAX_DATA));
    chunks.push(pktLine(Buffer.concat([Buffer.from([1]), Buffer.from(slice)])));
  }
  chunks.push(FLUSH);
  return Buffer.concat(chunks);
}

/** A request id for the X-GitHub-Request-Id header (not part of any scored export). */
export function newRequestId(): string {
  return randomUUID();
}
